<?php
// Comprobantes PDF deshabilitados: el historial de pedidos fue eliminado del panel admin.
http_response_code(410);
exit("Esta función ya no está disponible en ByteStock.");
?>
