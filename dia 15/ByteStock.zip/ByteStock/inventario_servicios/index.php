<?php


require_once __DIR__ . '/app/config/config.php';
require_once __DIR__ . '/app/seguridad/sesion.php';
iniciarSesionSegura();

require_once __DIR__ . '/app/helpers/csrf.php';
require_once __DIR__ . '/app/controllers/AuthController.php';
require_once __DIR__ . '/app/controllers/ClienteController.php';
require_once __DIR__ . '/app/controllers/AdminController.php';

$url = $_GET['url'] ?? 'login';

$auth = new AuthController();
$cliente = new ClienteController();
$admin = new AdminController();

switch ($url) {
    case 'login':
        $auth->login();
        break;
    case 'registro':
        $auth->registro();
        break;
    case 'logout':
        $auth->logout();
        break;
    case 'solicitar_servicio':
        $cliente->solicitarServicio();
        break;
    case 'dashboard':
    case 'admin':
        $admin->dashboard();
        break;
    case 'admin_inventario':
        $admin->inventario();
        break;
    case 'admin_editar_producto':
        $admin->editarProducto();
        break;
    case 'admin_eliminar_producto':
        $admin->eliminarProducto();
        break;
    case 'categorias':
        $admin->categorias();
        break;
    case 'clientes':
        $admin->clientes();
        break;
    case 'pedidos':
        $admin->pedidos();
        break;
    case 'reportes':
        $admin->reportes();
        break;
    case 'usuarios':
        $admin->usuarios();
        break;
    case 'api_graficos':
        $admin->apiGraficos();
        break;
    default:
        $auth->login();
        break;
}
?>
