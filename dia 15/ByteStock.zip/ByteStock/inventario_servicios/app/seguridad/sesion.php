<?php


declare(strict_types=1);

/** Tiempo máximo de inactividad (segundos). 30 minutos. */
if (!defined('INACTIVIDAD_MAX')) {
    define('INACTIVIDAD_MAX', 1800);
}

if (!defined('SESION_MAX')) {
    define('SESION_MAX', 28800);
}

if (!function_exists('iniciarSesionSegura')) {
    function iniciarSesionSegura(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
            'httponly' => true,
            'samesite' => 'Strict',
        ]);

        session_name('ZDTL_SESS');

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.cookie_samesite', 'Strict');

        session_start();
    }
}

if (!function_exists('abrirSesion')) {
    function abrirSesion(array $u): void
    {
        iniciarSesionSegura();
        session_regenerate_id(true);

        $_SESSION['usuario'] = [
            'id'     => (int) ($u['id'] ?? 0),
            'nombre' => (string) ($u['nombre'] ?? ''),
            'rol'    => (string) ($u['rol'] ?? 'cliente'),
            'correo' => (string) ($u['correo'] ?? ''),
        ];

        $_SESSION['inicio']           = time();
        $_SESSION['ultima_actividad'] = time();
        $_SESSION['huella']           = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
    }
}

if (!function_exists('cerrarSesion')) {
    function cerrarSesion(): void
    {
        iniciarSesionSegura();
        $_SESSION = [];

        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 42000,
                $p['path'],
                $p['domain'] ?? '',
                (bool) ($p['secure'] ?? false),
                (bool) ($p['httponly'] ?? true)
            );
        }

        session_destroy();
    }
}
