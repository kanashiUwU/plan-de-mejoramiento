<?php
/**
 * Guardián de acceso — incluir al inicio de toda página / acción privada.
 */

declare(strict_types=1);

require_once __DIR__ . '/sesion.php';

iniciarSesionSegura();

/* 1. ¿Hay sesión de usuario? */
if (empty($_SESSION['usuario']['id'])) {
    cerrarSesion();
    header('Location: index.php?url=login&m=sesion_requerida');
    exit;
}

/* 2. Huella del cliente */
$huellaActual = hash('sha256', $_SERVER['HTTP_USER_AGENT'] ?? '');
if (empty($_SESSION['huella']) || !hash_equals($_SESSION['huella'], $huellaActual)) {
    cerrarSesion();
    header('Location: index.php?url=login&m=sesion_invalida');
    exit;
}

/* 3. Expiración por inactividad y absoluta */
$ahora  = time();
$ultima = (int) ($_SESSION['ultima_actividad'] ?? 0);
$inicio = (int) ($_SESSION['inicio'] ?? 0);

$maxInactividad = defined('INACTIVIDAD_MAX') ? (int) INACTIVIDAD_MAX : 1800;
$maxSesion      = defined('SESION_MAX') ? (int) SESION_MAX : 28800;

if ($ultima === 0 || $inicio === 0
    || ($ahora - $ultima) >= $maxInactividad
    || ($ahora - $inicio) > $maxSesion
) {
    cerrarSesion();
    header('Location: index.php?url=login&m=sesion_expirada');
    exit;
}

$_SESSION['ultima_actividad'] = $ahora;

if (!function_exists('exigirRol')) {
    function exigirRol(string ...$roles): void
    {
        $rolActual = $_SESSION['usuario']['rol'] ?? '';
        if (!in_array($rolActual, $roles, true)) {
            http_response_code(403);
            exit('403 — No tiene permiso para esta operación.');
        }
    }
}

if (!function_exists('puede')) {
    function puede(string ...$roles): bool
    {
        $rolActual = $_SESSION['usuario']['rol'] ?? '';
        return in_array($rolActual, $roles, true);
    }
}
