<?php
class Database {
    private $host = "localhost";
    private $db_name = "inventario_servicios";
    private $username = "root";
    private $password = "";
    public $conn;

    public function getConnection() {
        $this->conn = null;
        try {
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
        } catch(PDOException $exception) {
            // No exponer detalles internos al usuario; registrar en el log del servidor
            error_log("Error de conexión a la BD: " . $exception->getMessage());
            die("Ocurrió un error al conectar con la base de datos. Intenta más tarde.");
        }
        return $this->conn;
    }
}
?>