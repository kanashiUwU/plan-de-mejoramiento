<?php
/**
 * Configuración global ByteStock
 * BASE_URL: ruta absoluta de la app (sin barra final).
 * Ajusta según tu entorno XAMPP, por ejemplo:
 *   http://localhost/ByteStock/inventario_servicios
 * o déjalo vacío para rutas relativas al front controller.
 */
declare(strict_types=1);

if (!defined('BASE_URL')) {
    // Detectar automáticamente a partir del script actual
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    $dir = rtrim(dirname($script), '/');
    // Si index.php está en la raíz del proyecto, BASE_URL es ese directorio
    define('BASE_URL', $dir === '/' ? '' : $dir);
}

/**
 * Genera una URL absoluta de la aplicación.
 * Ejemplo: url('dashboard') → /ruta/index.php?url=dashboard
 */
if (!function_exists('url')) {
    function url(string $ruta = '', array $params = []): string
    {
        $base = BASE_URL . '/index.php';
        if ($ruta !== '') {
            $params = array_merge(['url' => $ruta], $params);
        }
        $qs = http_build_query($params);
        return $qs !== '' ? $base . '?' . $qs : $base;
    }
}
