<?php
require_once __DIR__ . '/../config/database.php';

class InventarioModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
        $this->asegurarColumnas();
    }

    private function asegurarColumnas() {
        try {
            $cols = [
                'precio' => "ALTER TABLE inventario ADD COLUMN precio DECIMAL(12,2) NOT NULL DEFAULT 0",
                'imagen' => "ALTER TABLE inventario ADD COLUMN imagen VARCHAR(255) NULL DEFAULT NULL",
                'categoria_id' => "ALTER TABLE inventario ADD COLUMN categoria_id INT NULL",
                'activo' => "ALTER TABLE inventario ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1",
                'stock_minimo' => "ALTER TABLE inventario ADD COLUMN stock_minimo INT NOT NULL DEFAULT 5",
                'actualizado_en' => "ALTER TABLE inventario ADD COLUMN actualizado_en TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP",
            ];
            foreach ($cols as $col => $sql) {
                $check = $this->conn->query("SHOW COLUMNS FROM inventario LIKE '$col'");
                if ($check && $check->rowCount() === 0) {
                    $this->conn->exec($sql);
                }
            }
        } catch (PDOException $e) {
            error_log("InventarioModel columnas: " . $e->getMessage());
        }
    }

    /**
     * Listado con búsqueda, ordenamiento y paginación (10 por página).
     * @return array ['rows'=>[], 'total'=>int, 'page'=>int, 'pages'=>int]
     */
    public function listar($busqueda = '', $orden = 'id', $dir = 'DESC', $page = 1, $perPage = 10, $soloActivos = false) {
        $page = max(1, (int)$page);
        $perPage = max(1, min(50, (int)$perPage));
        $offset = ($page - 1) * $perPage;

        $allowedOrden = ['id', 'nombre_producto', 'cantidad', 'precio', 'creado_en', 'categoria'];
        $orden = in_array($orden, $allowedOrden, true) ? $orden : 'id';
        $dir = strtoupper($dir) === 'ASC' ? 'ASC' : 'DESC';

        $where = [];
        $params = [];
        if ($soloActivos) {
            $where[] = "(i.activo = 1 OR i.activo IS NULL)";
        }
        if ($busqueda !== '') {
            $where[] = "(i.nombre_producto LIKE ? OR i.descripcion LIKE ? OR COALESCE(c.nombre,'') LIKE ?)";
            $like = '%' . $busqueda . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        $whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

        $orderCol = $orden === 'categoria' ? 'c.nombre' : 'i.' . $orden;

        // Total
        $sqlCount = "SELECT COUNT(*) FROM inventario i LEFT JOIN categorias c ON c.id = i.categoria_id $whereSql";
        $stmtC = $this->conn->prepare($sqlCount);
        $stmtC->execute($params);
        $total = (int)$stmtC->fetchColumn();
        $pages = max(1, (int)ceil($total / $perPage));

        $sql = "SELECT i.*, COALESCE(c.nombre, 'Sin categoría') AS categoria_nombre
                FROM inventario i
                LEFT JOIN categorias c ON c.id = i.categoria_id
                $whereSql
                ORDER BY $orderCol $dir
                LIMIT $perPage OFFSET $offset";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'perPage' => $perPage,
        ];
    }

    public function obtenerTodos($busqueda = '') {
        $res = $this->listar($busqueda, 'id', 'DESC', 1, 500, false);
        return $res['rows'];
    }

    public function obtenerPorId($id) {
        $stmt = $this->conn->prepare(
            "SELECT i.*, COALESCE(c.nombre, 'Sin categoría') AS categoria_nombre
             FROM inventario i
             LEFT JOIN categorias c ON c.id = i.categoria_id
             WHERE i.id = ?"
        );
        $stmt->execute([(int)$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function insertar($nombre, $descripcion, $cantidad, $precio = 0, $imagen = null, $categoria_id = null, $stock_minimo = 5) {
        $nombre = trim($nombre);
        if ($nombre === '' || $cantidad < 0) return false;
        $precio = max(0, (float)$precio);
        $stock_minimo = max(0, (int)$stock_minimo);
        $stmt = $this->conn->prepare(
            "INSERT INTO inventario (nombre_producto, descripcion, cantidad, unidad_medida, precio, imagen, categoria_id, stock_minimo, activo)
             VALUES (?, ?, ?, 'Unidades', ?, ?, ?, ?, 1)"
        );
        return $stmt->execute([$nombre, $descripcion, (int)$cantidad, $precio, $imagen, $categoria_id ?: null, $stock_minimo]);
    }

    public function actualizar($id, $nombre, $descripcion, $cantidad, $precio = 0, $imagen = null, $categoria_id = null, $stock_minimo = 5) {
        $nombre = trim($nombre);
        if ($nombre === '' || $cantidad < 0) return false;
        $precio = max(0, (float)$precio);
        $stock_minimo = max(0, (int)$stock_minimo);
        if ($imagen !== null && $imagen !== '') {
            $stmt = $this->conn->prepare(
                "UPDATE inventario SET nombre_producto=?, descripcion=?, cantidad=?, precio=?, imagen=?, categoria_id=?, stock_minimo=? WHERE id=?"
            );
            return $stmt->execute([$nombre, $descripcion, (int)$cantidad, $precio, $imagen, $categoria_id ?: null, $stock_minimo, (int)$id]);
        }
        $stmt = $this->conn->prepare(
            "UPDATE inventario SET nombre_producto=?, descripcion=?, cantidad=?, precio=?, categoria_id=?, stock_minimo=? WHERE id=?"
        );
        return $stmt->execute([$nombre, $descripcion, (int)$cantidad, $precio, $categoria_id ?: null, $stock_minimo, (int)$id]);
    }

    /** Soft delete / desactivar */
    public function desactivar($id) {
        $stmt = $this->conn->prepare("UPDATE inventario SET activo = 0 WHERE id = ?");
        return $stmt->execute([(int)$id]);
    }

    public function activar($id) {
        $stmt = $this->conn->prepare("UPDATE inventario SET activo = 1 WHERE id = ?");
        return $stmt->execute([(int)$id]);
    }

    /** Hard delete (solo si no hay detalles de pedido) */
    public function eliminar($id) {
        try {
            $stmt = $this->conn->prepare("DELETE FROM inventario WHERE id = ?");
            return $stmt->execute([(int)$id]);
        } catch (PDOException $e) {
            // Si hay FK, desactivar en su lugar
            return $this->desactivar($id);
        }
    }

    public function descontarStock($producto_id, $cantidad) {
        $stmt = $this->conn->prepare(
            "UPDATE inventario SET cantidad = cantidad - ? WHERE id = ? AND cantidad >= ?"
        );
        return $stmt->execute([(int)$cantidad, (int)$producto_id, (int)$cantidad]);
    }

    public function contarProductos($soloActivos = true) {
        $sql = $soloActivos
            ? "SELECT COUNT(*) FROM inventario WHERE activo = 1 OR activo IS NULL"
            : "SELECT COUNT(*) FROM inventario";
        $stmt = $this->conn->query($sql);
        return (int)$stmt->fetchColumn();
    }

    public function totalUnidadesStock() {
        $stmt = $this->conn->query("SELECT COALESCE(SUM(cantidad), 0) FROM inventario WHERE activo = 1 OR activo IS NULL");
        return (int)$stmt->fetchColumn();
    }

    public function obtenerCategorias() {
        try {
            $stmt = $this->conn->query("SELECT id, nombre FROM categorias WHERE activo = 1 OR activo IS NULL ORDER BY nombre");
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }

    public function existeNombre($nombre, $excludeId = null) {
        if ($excludeId) {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM inventario WHERE nombre_producto = ? AND id != ?");
            $stmt->execute([trim($nombre), (int)$excludeId]);
        } else {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM inventario WHERE nombre_producto = ?");
            $stmt->execute([trim($nombre)]);
        }
        return (int)$stmt->fetchColumn() > 0;
    }
}
?>
