<?php
require_once __DIR__ . '/../config/database.php';

class UsuarioModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->asegurarColumnasBloqueo();
    }

    private function asegurarColumnasBloqueo() {
        try {
            $c = $this->db->query("SHOW COLUMNS FROM usuarios LIKE 'intentos_fallidos'");
            if ($c && $c->rowCount() === 0) {
                $this->db->exec("ALTER TABLE usuarios ADD COLUMN intentos_fallidos INT NOT NULL DEFAULT 0");
            }
            $c2 = $this->db->query("SHOW COLUMNS FROM usuarios LIKE 'bloqueado_hasta'");
            if ($c2 && $c2->rowCount() === 0) {
                $this->db->exec("ALTER TABLE usuarios ADD COLUMN bloqueado_hasta DATETIME NULL DEFAULT NULL");
            }
        } catch (PDOException $e) {
            error_log("UsuarioModel columnas: " . $e->getMessage());
        }
    }

    public function registrar($nombre, $correo, $telefono, $password) {
        try {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO usuarios (nombre, correo, telefono, password) VALUES (?, ?, ?, ?)";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$nombre, $correo, $telefono, $hash]);
        } catch (\PDOException $e) {
            if ($e->errorInfo[1] == 1062) {
                return "duplicado";
            }
            throw $e;
        }
    }

    public function login($correo) {
        $query = "SELECT * FROM usuarios WHERE correo = ?";
        $stmt = $this->db->prepare($query);
        $stmt->execute([$correo]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function registrarIntentoFallido($id) {
        $stmt = $this->db->prepare(
            "UPDATE usuarios SET intentos_fallidos = intentos_fallidos + 1 WHERE id = ?"
        );
        $stmt->execute([$id]);
        $stmt2 = $this->db->prepare("SELECT intentos_fallidos FROM usuarios WHERE id = ?");
        $stmt2->execute([$id]);
        $row = $stmt2->fetch(PDO::FETCH_ASSOC);
        $intentos = (int)($row['intentos_fallidos'] ?? 0);
        if ($intentos >= 5) {
            // Bloqueo 30 minutos
            $stmt3 = $this->db->prepare(
                "UPDATE usuarios SET bloqueado_hasta = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE id = ?"
            );
            $stmt3->execute([$id]);
        }
        return $intentos;
    }

    public function resetearIntentos($id) {
        $stmt = $this->db->prepare(
            "UPDATE usuarios SET intentos_fallidos = 0, bloqueado_hasta = NULL WHERE id = ?"
        );
        return $stmt->execute([$id]);
    }

    public function estaBloqueado($user) {
        if (empty($user['bloqueado_hasta'])) {
            return false;
        }
        return strtotime($user['bloqueado_hasta']) > time();
    }
}
?>
