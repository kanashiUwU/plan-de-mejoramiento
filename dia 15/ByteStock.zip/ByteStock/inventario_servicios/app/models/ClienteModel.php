<?php
require_once __DIR__ . '/../config/database.php';

class ClienteModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
        $this->asegurarColumnas();
    }

    private function asegurarColumnas() {
        try {
            $check = $this->conn->query("SHOW COLUMNS FROM usuarios LIKE 'activo'");
            if ($check && $check->rowCount() === 0) {
                $this->conn->exec("ALTER TABLE usuarios ADD COLUMN activo TINYINT(1) NOT NULL DEFAULT 1");
            }
        } catch (PDOException $e) {
            error_log("ClienteModel columnas: " . $e->getMessage());
        }
    }

    /**
     * Listado de clientes con búsqueda, orden y paginación.
     */
    public function listar($busqueda = '', $orden = 'id', $dir = 'DESC', $page = 1, $perPage = 10) {
        $page = max(1, (int)$page);
        $perPage = max(1, min(50, (int)$perPage));
        $offset = ($page - 1) * $perPage;

        $allowed = ['id', 'nombre', 'correo', 'telefono', 'creado_en', 'total_pedidos', 'total_gastado'];
        $orden = in_array($orden, $allowed, true) ? $orden : 'id';
        $dir = strtoupper($dir) === 'ASC' ? 'ASC' : 'DESC';

        $where = ["(u.rol = 'cliente' OR u.rol IS NULL OR u.rol = '')"];
        $params = [];
        if ($busqueda !== '') {
            $where[] = "(u.nombre LIKE ? OR u.correo LIKE ? OR u.telefono LIKE ?)";
            $like = '%' . $busqueda . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }
        $whereSql = 'WHERE ' . implode(' AND ', $where);

        $sqlCount = "SELECT COUNT(DISTINCT u.id) FROM usuarios u $whereSql";
        $stmtC = $this->conn->prepare($sqlCount);
        $stmtC->execute($params);
        $total = (int)$stmtC->fetchColumn();
        $pages = max(1, (int)ceil($total / $perPage));

        $orderCol = in_array($orden, ['total_pedidos', 'total_gastado'], true)
            ? $orden
            : 'u.' . $orden;

        $sql = "SELECT u.id, u.nombre, u.correo, u.telefono, u.creado_en,
                       COALESCE(u.activo, 1) AS activo,
                       COUNT(p.id) AS total_pedidos,
                       COALESCE(SUM(p.total_pagado), 0) AS total_gastado
                FROM usuarios u
                LEFT JOIN pedidos p ON p.usuario_id = u.id
                $whereSql
                GROUP BY u.id, u.nombre, u.correo, u.telefono, u.creado_en, u.activo
                ORDER BY $orderCol $dir
                LIMIT $perPage OFFSET $offset";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return [
            'rows' => $rows,
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
            'perPage' => $perPage,
        ];
    }

    public function obtenerPorId($id) {
        $stmt = $this->conn->prepare(
            "SELECT id, nombre, correo, telefono, rol, creado_en, COALESCE(activo,1) AS activo
             FROM usuarios WHERE id = ? AND (rol = 'cliente' OR rol IS NULL OR rol = '')"
        );
        $stmt->execute([(int)$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function crear($nombre, $correo, $telefono, $password = null) {
        $nombre = trim($nombre);
        $correo = trim(strtolower($correo));
        $telefono = trim($telefono);
        if ($nombre === '' || $correo === '') return ['ok' => false, 'error' => 'Nombre y correo son obligatorios.'];
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'error' => 'Correo inválido.'];
        if ($this->existeCorreo($correo)) return ['ok' => false, 'error' => 'El correo ya está registrado.'];

        $pass = $password ?: ('Cliente' . random_int(1000, 9999) . '!');
        $hash = password_hash($pass, PASSWORD_BCRYPT);

        $stmt = $this->conn->prepare(
            "INSERT INTO usuarios (nombre, correo, telefono, password, rol, activo) VALUES (?, ?, ?, ?, 'cliente', 1)"
        );
        $ok = $stmt->execute([$nombre, $correo, $telefono, $hash]);
        return $ok ? ['ok' => true, 'id' => (int)$this->conn->lastInsertId(), 'password_temp' => $pass]
                   : ['ok' => false, 'error' => 'No se pudo crear el cliente.'];
    }

    public function actualizar($id, $nombre, $correo, $telefono) {
        $nombre = trim($nombre);
        $correo = trim(strtolower($correo));
        $telefono = trim($telefono);
        if ($nombre === '' || $correo === '') return ['ok' => false, 'error' => 'Nombre y correo son obligatorios.'];
        if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) return ['ok' => false, 'error' => 'Correo inválido.'];
        if ($this->existeCorreo($correo, $id)) return ['ok' => false, 'error' => 'El correo ya está registrado por otro usuario.'];

        $stmt = $this->conn->prepare(
            "UPDATE usuarios SET nombre=?, correo=?, telefono=? WHERE id=? AND (rol='cliente' OR rol IS NULL OR rol='')"
        );
        $ok = $stmt->execute([$nombre, $correo, $telefono, (int)$id]);
        return $ok ? ['ok' => true] : ['ok' => false, 'error' => 'No se pudo actualizar.'];
    }

    public function desactivar($id) {
        $stmt = $this->conn->prepare("UPDATE usuarios SET activo = 0 WHERE id = ? AND rol = 'cliente'");
        return $stmt->execute([(int)$id]);
    }

    public function activar($id) {
        $stmt = $this->conn->prepare("UPDATE usuarios SET activo = 1 WHERE id = ? AND rol = 'cliente'");
        return $stmt->execute([(int)$id]);
    }

    public function existeCorreo($correo, $excludeId = null) {
        if ($excludeId) {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM usuarios WHERE correo = ? AND id != ?");
            $stmt->execute([trim(strtolower($correo)), (int)$excludeId]);
        } else {
            $stmt = $this->conn->prepare("SELECT COUNT(*) FROM usuarios WHERE correo = ?");
            $stmt->execute([trim(strtolower($correo))]);
        }
        return (int)$stmt->fetchColumn() > 0;
    }

    public function listarSelect() {
        $stmt = $this->conn->query(
            "SELECT id, nombre, correo FROM usuarios
             WHERE (rol = 'cliente' OR rol IS NULL OR rol = '') AND (activo = 1 OR activo IS NULL)
             ORDER BY nombre"
        );
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
