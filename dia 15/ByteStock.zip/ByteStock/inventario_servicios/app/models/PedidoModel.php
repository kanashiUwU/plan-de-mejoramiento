<?php
require_once __DIR__ . '/../config/database.php';

class PedidoModel {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->getConnection();
        $this->asegurarTablas();
    }

    private function asegurarTablas() {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS pedido_detalle (
                  id INT AUTO_INCREMENT PRIMARY KEY,
                  pedido_id INT NOT NULL,
                  producto_id INT NOT NULL,
                  nombre_producto VARCHAR(150) NOT NULL,
                  cantidad INT NOT NULL DEFAULT 1,
                  precio_unitario DECIMAL(12,2) NOT NULL DEFAULT 0,
                  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0
                ) ENGINE=InnoDB
            ");
            $check = $this->conn->query("SHOW COLUMNS FROM pedidos LIKE 'estado'");
            if ($check && $check->rowCount() === 0) {
                $this->conn->exec("ALTER TABLE pedidos ADD COLUMN estado ENUM('pendiente','completado','cancelado') NOT NULL DEFAULT 'completado'");
            }
            try {
                $this->conn->exec("ALTER TABLE pedidos MODIFY direccion VARCHAR(255) NULL DEFAULT NULL");
            } catch (PDOException $e) { }
            try {
                $this->conn->exec("ALTER TABLE pedidos MODIFY metodo_pago VARCHAR(100) NULL DEFAULT NULL");
            } catch (PDOException $e) { }
            try {
                $this->conn->exec("ALTER TABLE pedidos MODIFY referencia_pago VARCHAR(150) NULL DEFAULT NULL");
            } catch (PDOException $e) { }
        } catch (PDOException $e) {
            error_log("PedidoModel tablas: " . $e->getMessage());
        }
    }

    /**
     * Crear pedido con detalle y descuento de stock en una transacción.
     * $items = [ ['producto_id'=>1, 'cantidad'=>2], ... ]
     */
    public function crearConDetalle($usuario_id, $items, $direccion = null, $metodo_pago = null, $referencia = null, $estado = 'completado') {
        if (empty($items) || !$usuario_id) {
            return ['ok' => false, 'error' => 'Datos incompletos.'];
        }

        try {
            $this->conn->beginTransaction();

            $total = 0;
            $lineas = [];
            $nombres = [];

            foreach ($items as $it) {
                $pid = (int)($it['producto_id'] ?? 0);
                $cant = (int)($it['cantidad'] ?? 0);
                if ($pid <= 0 || $cant <= 0) {
                    throw new Exception('Ítem inválido.');
                }
                $stmt = $this->conn->prepare(
                    "SELECT id, nombre_producto, cantidad, precio, COALESCE(activo,1) AS activo
                     FROM inventario WHERE id = ? FOR UPDATE"
                );
                $stmt->execute([$pid]);
                $prod = $stmt->fetch(PDO::FETCH_ASSOC);
                if (!$prod || !(int)$prod['activo']) {
                    throw new Exception("Producto #$pid no disponible.");
                }
                if ((int)$prod['cantidad'] < $cant) {
                    throw new Exception("Stock insuficiente para: " . $prod['nombre_producto'] . " (disponible: {$prod['cantidad']}).");
                }
                $sub = (float)$prod['precio'] * $cant;
                $total += $sub;
                $lineas[] = [
                    'producto_id' => $pid,
                    'nombre' => $prod['nombre_producto'],
                    'cantidad' => $cant,
                    'precio' => (float)$prod['precio'],
                    'subtotal' => $sub,
                ];
                $nombres[] = $prod['nombre_producto'] . ' x' . $cant;
            }

            $resumen = implode(', ', array_slice($nombres, 0, 3));
            if (count($nombres) > 3) $resumen .= '...';

            $estadoVal = in_array($estado, ['pendiente','completado','cancelado'], true) ? $estado : 'completado';
            // Evitar NULL en columnas NOT NULL de la BD
            $direccionVal   = ($direccion === null || $direccion === '') ? 'Sin especificar' : $direccion;
            $metodoVal      = ($metodo_pago === null || $metodo_pago === '') ? 'Pendiente' : $metodo_pago;
            $referenciaVal  = ($referencia === null || $referencia === '') ? '' : $referencia;
            $stmtP = $this->conn->prepare(
                "INSERT INTO pedidos (usuario_id, tipo_servicio, direccion, metodo_pago, referencia_pago, total_pagado, estado)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $stmtP->execute([
                (int)$usuario_id,
                $resumen,
                $direccionVal,
                $metodoVal,
                $referenciaVal,
                $total,
                $estadoVal,
            ]);
            $pedidoId = (int)$this->conn->lastInsertId();

            $stmtD = $this->conn->prepare(
                "INSERT INTO pedido_detalle (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario, subtotal)
                 VALUES (?, ?, ?, ?, ?, ?)"
            );
            $stmtStock = $this->conn->prepare(
                "UPDATE inventario SET cantidad = cantidad - ? WHERE id = ? AND cantidad >= ?"
            );

            foreach ($lineas as $l) {
                $stmtD->execute([$pedidoId, $l['producto_id'], $l['nombre'], $l['cantidad'], $l['precio'], $l['subtotal']]);
                $ok = $stmtStock->execute([$l['cantidad'], $l['producto_id'], $l['cantidad']]);
                if (!$ok || $stmtStock->rowCount() === 0) {
                    throw new Exception("No se pudo descontar stock de: " . $l['nombre']);
                }
            }

            $this->conn->commit();
            return ['ok' => true, 'pedido_id' => $pedidoId, 'total' => $total];
        } catch (Exception $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /** Compatibilidad con el método antiguo (un solo producto) */
    public function crear($usuario_id, $servicio, $direccion, $pago, $ref, $total) {
        $stmt = $this->conn->prepare(
            "INSERT INTO pedidos (usuario_id, tipo_servicio, direccion, metodo_pago, referencia_pago, total_pagado)
             VALUES (?, ?, ?, ?, ?, ?)"
        );
        return $stmt->execute([$usuario_id, $servicio, $direccion, $pago, $ref, $total]);
    }

    public function obtenerHistorial($limit = 100) {
        $query = "SELECT p.*, u.nombre AS cliente_nombre, u.correo
                  FROM pedidos p
                  LEFT JOIN usuarios u ON p.usuario_id = u.id
                  ORDER BY p.id DESC
                  LIMIT " . (int)$limit;
        $stmt = $this->conn->query($query);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorPeriodo($dias) {
        $query = "SELECT p.*, u.nombre AS cliente_nombre, u.correo
                  FROM pedidos p
                  LEFT JOIN usuarios u ON p.usuario_id = u.id
                  WHERE p.fecha_pedido >= DATE_SUB(NOW(), INTERVAL ? DAY)
                  ORDER BY p.fecha_pedido DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([(int)$dias]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function totalesPorPeriodo($dias) {
        $query = "SELECT COUNT(*) AS total_ventas, COALESCE(SUM(total_pagado), 0) AS total_monto
                  FROM pedidos
                  WHERE fecha_pedido >= DATE_SUB(NOW(), INTERVAL ? DAY)";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([(int)$dias]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id) {
        $query = "SELECT p.*, u.nombre AS cliente_nombre, u.correo, u.telefono
                  FROM pedidos p
                  LEFT JOIN usuarios u ON p.usuario_id = u.id
                  WHERE p.id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([(int)$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerDetalle($pedido_id) {
        $stmt = $this->conn->prepare(
            "SELECT * FROM pedido_detalle WHERE pedido_id = ? ORDER BY id"
        );
        $stmt->execute([(int)$pedido_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listar($busqueda = '', $page = 1, $perPage = 10) {
        $page = max(1, (int)$page);
        $perPage = max(1, min(50, (int)$perPage));
        $offset = ($page - 1) * $perPage;
        $params = [];
        $where = '';
        if ($busqueda !== '') {
            $where = "WHERE p.tipo_servicio LIKE ? OR u.nombre LIKE ? OR u.correo LIKE ?";
            $like = '%' . $busqueda . '%';
            $params = [$like, $like, $like];
        }
        $stmtC = $this->conn->prepare(
            "SELECT COUNT(*) FROM pedidos p LEFT JOIN usuarios u ON u.id = p.usuario_id $where"
        );
        $stmtC->execute($params);
        $total = (int)$stmtC->fetchColumn();
        $pages = max(1, (int)ceil($total / $perPage));

        $sql = "SELECT p.*, u.nombre AS cliente_nombre, u.correo
                FROM pedidos p
                LEFT JOIN usuarios u ON u.id = p.usuario_id
                $where
                ORDER BY p.fecha_pedido DESC
                LIMIT $perPage OFFSET $offset";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return [
            'rows' => $stmt->fetchAll(PDO::FETCH_ASSOC),
            'total' => $total,
            'page' => $page,
            'pages' => $pages,
        ];
    }
}
?>
