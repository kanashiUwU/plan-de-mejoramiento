<?php
require_once __DIR__ . '/../models/UsuarioModel.php';
require_once __DIR__ . '/../seguridad/sesion.php';

class AuthController {
    private $model;

    public function __construct() {
        iniciarSesionSegura();
        $this->model = new UsuarioModel();
    }

    public function login() {
        // Si ya hay sesión válida, redirigir según rol
        if (!empty($_SESSION['usuario']['id'])) {
            if (($_SESSION['usuario']['rol'] ?? '') === 'admin') {
                header("Location: index.php?url=dashboard");
            } else {
                header("Location: index.php?url=solicitar_servicio");
            }
            exit();
        }

        $error = "";
        $mensaje = "";

        // Mensajes del guardián / salir
        $m = $_GET['m'] ?? '';
        if ($m === 'sesion_expirada') {
            $mensaje = "Su sesión ha expirado por inactividad. Inicie sesión de nuevo.";
        } elseif ($m === 'sesion_requerida' || $m === 'sesion_invalida') {
            $mensaje = "Debe iniciar sesión para acceder a esa página.";
        } elseif ($m === 'sesion_cerrada') {
            $mensaje = "Ha cerrado sesión correctamente.";
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $correo = trim($_POST['correo'] ?? '');
            $password = $_POST['password'] ?? '';
            $user = $this->model->login($correo);

            if ($user && $this->model->estaBloqueado($user)) {
                $hasta = date('d/m/Y H:i', strtotime($user['bloqueado_hasta']));
                $error = "Cuenta bloqueada por demasiados intentos fallidos. Intenta de nuevo después de las $hasta.";
            } elseif ($user && isset($user['activo']) && (int)$user['activo'] === 0) {
                $error = "Tu cuenta está desactivada. Contacta al administrador.";
            } elseif ($user && password_verify($password, $user['password'])) {
                $this->model->resetearIntentos($user['id']);

                // Abrir sesión SEGURA: regenera ID + guarda inicio, ultima_actividad y huella
                // (sin esto el guardián cierra la sesión al instante)
                abrirSesion($user);

                $rol = $user['rol'] ?? 'cliente';
                if (in_array($rol, ['admin', 'vendedor', 'consultor'], true)) {
                    header("Location: index.php?url=dashboard");
                } else {
                    header("Location: index.php?url=solicitar_servicio");
                }
                exit();
            } else {
                if ($user) {
                    $intentos = $this->model->registrarIntentoFallido($user['id']);
                    if ($intentos >= 5) {
                        $error = "Cuenta bloqueada por 30 minutos tras 5 intentos fallidos.";
                    } else {
                        $restantes = 5 - $intentos;
                        $error = "Credenciales incorrectas. Te quedan $restantes intento(s) antes del bloqueo.";
                    }
                } else {
                    $error = "Credenciales incorrectas";
                }
            }
        }

        require_once __DIR__ . '/../views/auth/login.php';
    }

    public function registro() {
        if (!empty($_SESSION['usuario']['id'])) {
            header("Location: index.php?url=login");
            exit();
        }

        $error = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = trim($_POST['nombre'] ?? '');
            $correo = trim($_POST['correo'] ?? '');
            $telefono = trim($_POST['telefono'] ?? '');
            $password = $_POST['password'] ?? '';

            if ($nombre === '' || $correo === '' || $telefono === '' || $password === '') {
                $error = "Todos los campos son obligatorios";
            } elseif (strlen($password) < 6) {
                $error = "La contraseña debe tener al menos 6 caracteres";
            } else {
                $resultado = $this->model->registrar($nombre, $correo, $telefono, $password);
                if ($resultado === "duplicado") {
                    $error = "Ese correo ya está registrado";
                } else {
                    header("Location: index.php?url=login");
                    exit();
                }
            }
        }
        require_once __DIR__ . '/../views/auth/registro.php';
    }

    public function logout() {
        cerrarSesion();
        header("Location: index.php?url=login&m=sesion_cerrada");
        exit();
    }
}
