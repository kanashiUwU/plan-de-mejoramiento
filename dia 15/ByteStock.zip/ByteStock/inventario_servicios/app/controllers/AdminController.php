<?php
require_once __DIR__ . '/../models/InventarioModel.php';
require_once __DIR__ . '/../models/PedidoModel.php';
require_once __DIR__ . '/../models/ClienteModel.php';

class AdminController {
    private $inventarioModel;
    private $pedidoModel;
    private $clienteModel;

    public function __construct() {
        $this->inventarioModel = new InventarioModel();
        $this->pedidoModel = new PedidoModel();
        $this->clienteModel = new ClienteModel();
    }

    private function proteger(): void {
        require_once __DIR__ . '/../seguridad/guardia.php';
    }

    /** Evita reenvío de formularios (Post-Redirect-Get) */
    private function flash($tipo, $msg) {
        $_SESSION['flash'] = ['tipo' => $tipo, 'msg' => $msg];
    }

    private function takeFlash() {
        $f = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $f;
    }

    public function inventario() {
        $this->proteger();
        exigirRol('admin', 'vendedor', 'consultor');

        $error = '';
        $flash = $this->takeFlash();

        // Crear producto (solo admin/vendedor)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar'])) {
            if (!puede('admin', 'vendedor')) {
                $error = 'No tienes permiso para agregar productos.';
            } elseif (!csrf_verify($_POST['csrf_token'] ?? '')) {
                $error = 'Token de seguridad inválido. Recarga la página e intenta de nuevo.';
            } else {
                $nombre = trim($_POST['nombre'] ?? '');
                $desc = trim($_POST['descripcion'] ?? '');
                $cantidad = intval($_POST['cantidad'] ?? -1);
                $precio = floatval($_POST['precio'] ?? 0);
                $imagen = trim($_POST['imagen'] ?? '') ?: null;
                $cat = !empty($_POST['categoria_id']) ? (int)$_POST['categoria_id'] : null;
                $stockMin = max(0, intval($_POST['stock_minimo'] ?? 5));

                if ($nombre === '') {
                    $error = 'El nombre del producto es obligatorio.';
                } elseif ($cantidad < 0) {
                    $error = 'La cantidad no puede ser negativa.';
                } elseif ($precio < 0) {
                    $error = 'El precio no puede ser negativo.';
                } elseif ($this->inventarioModel->existeNombre($nombre)) {
                    $error = 'Ya existe un producto con ese nombre.';
                } else {
                    $ok = $this->inventarioModel->insertar($nombre, $desc, $cantidad, $precio, $imagen, $cat, $stockMin);
                    if ($ok) {
                        $this->flash('ok', 'Producto agregado correctamente.');
                        header('Location: index.php?url=admin_inventario');
                        exit;
                    }
                    $error = 'No se pudo guardar el producto.';
                }
            }
        }

        // Desactivar / eliminar
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['desactivar_producto'])) {
            if (puede('admin', 'vendedor') && csrf_verify($_POST['csrf_token'] ?? '')) {
                $id = (int)($_POST['id'] ?? 0);
                if ($id) {
                    $this->inventarioModel->desactivar($id);
                    $this->flash('ok', 'Producto desactivado.');
                }
            }
            header('Location: index.php?url=admin_inventario');
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activar_producto'])) {
            if (puede('admin', 'vendedor') && csrf_verify($_POST['csrf_token'] ?? '')) {
                $id = (int)($_POST['id'] ?? 0);
                if ($id) {
                    $this->inventarioModel->activar($id);
                    $this->flash('ok', 'Producto reactivado.');
                }
            }
            header('Location: index.php?url=admin_inventario');
            exit;
        }

        $busqueda = trim($_GET['q'] ?? '');
        $orden = $_GET['orden'] ?? 'id';
        $dir = $_GET['dir'] ?? 'DESC';
        $page = max(1, (int)($_GET['page'] ?? 1));

        $lista = $this->inventarioModel->listar($busqueda, $orden, $dir, $page, 10, false);
        $productos = $lista['rows'];
        $totalProductos = $lista['total'];
        $totalUnidades = $this->inventarioModel->totalUnidadesStock();
        $categorias = $this->inventarioModel->obtenerCategorias();

        $pedidos = $this->pedidoModel->obtenerHistorial(50);
        $totalVentas = count($pedidos);
        $totalGanancias = 0;
        foreach ($pedidos as $p) {
            $totalGanancias += (float)$p['total_pagado'];
        }
        $comprasSemana = $this->pedidoModel->obtenerPorPeriodo(7);
        $comprasMes = $this->pedidoModel->obtenerPorPeriodo(30);
        $totalesSemana = $this->pedidoModel->totalesPorPeriodo(7);
        $totalesMes = $this->pedidoModel->totalesPorPeriodo(30);

        $paginacion = $lista;
        require_once __DIR__ . '/../views/admin/inventario.php';
    }

    public function editarProducto() {
        $this->proteger();
        exigirRol('admin', 'vendedor');

        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: index.php?url=admin_inventario');
            exit;
        }

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!csrf_verify($_POST['csrf_token'] ?? '')) {
                $error = 'Token de seguridad inválido. Recarga la página e intenta de nuevo.';
            } else {
                $nombre = trim($_POST['nombre'] ?? '');
                $desc = trim($_POST['descripcion'] ?? '');
                $cantidad = intval($_POST['cantidad'] ?? -1);
                $precio = floatval($_POST['precio'] ?? 0);
                $imagen = trim($_POST['imagen'] ?? '') ?: null;
                $cat = !empty($_POST['categoria_id']) ? (int)$_POST['categoria_id'] : null;
                $stockMin = max(0, intval($_POST['stock_minimo'] ?? 5));

                if ($nombre === '') {
                    $error = 'El nombre es obligatorio.';
                } elseif ($cantidad < 0) {
                    $error = 'La cantidad no puede ser negativa.';
                } elseif ($this->inventarioModel->existeNombre($nombre, $id)) {
                    $error = 'Ya existe otro producto con ese nombre.';
                } else {
                    $ok = $this->inventarioModel->actualizar($id, $nombre, $desc, $cantidad, $precio, $imagen, $cat, $stockMin);
                    if ($ok) {
                        $this->flash('ok', 'Producto actualizado.');
                        header('Location: index.php?url=admin_inventario');
                        exit;
                    }
                    $error = 'No se pudo actualizar.';
                }
            }
        }
        $producto = $this->inventarioModel->obtenerPorId($id);
        if (!$producto) {
            header('Location: index.php?url=admin_inventario');
            exit;
        }
        $categorias = $this->inventarioModel->obtenerCategorias();
        require_once __DIR__ . '/../views/admin/editar_producto.php';
    }

    public function eliminarProducto() {
        $this->proteger();
        exigirRol('admin', 'vendedor');
        if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_verify($_POST['csrf_token'] ?? '')) {
            header('Location: index.php?url=admin_inventario');
            exit;
        }
        $id = $_POST['id'] ?? null;
        if ($id) {
            $this->inventarioModel->desactivar($id); // soft delete preferido
        }
        header('Location: index.php?url=admin_inventario');
        exit;
    }

    // =========================================================================
    // CLIENTES — CRUD completo
    // =========================================================================
    public function clientes() {
        $this->proteger();
        exigirRol('admin', 'vendedor');

        $error = '';
        $flash = $this->takeFlash();

        // Crear
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear_cliente'])) {
            if (!csrf_verify($_POST['csrf_token'] ?? '')) {
                $error = 'Token inválido.';
            } else {
                $res = $this->clienteModel->crear(
                    $_POST['nombre'] ?? '',
                    $_POST['correo'] ?? '',
                    $_POST['telefono'] ?? '',
                    $_POST['password'] ?? null
                );
                if ($res['ok']) {
                    $msg = 'Cliente creado.';
                    if (!empty($res['password_temp'])) {
                        $msg .= ' Contraseña temporal: ' . $res['password_temp'];
                    }
                    $this->flash('ok', $msg);
                    header('Location: index.php?url=clientes');
                    exit;
                }
                $error = $res['error'] ?? 'Error al crear.';
            }
        }

        // Editar
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_cliente'])) {
            if (!csrf_verify($_POST['csrf_token'] ?? '')) {
                $error = 'Token inválido.';
            } else {
                $id = (int)($_POST['id'] ?? 0);
                $res = $this->clienteModel->actualizar($id, $_POST['nombre'] ?? '', $_POST['correo'] ?? '', $_POST['telefono'] ?? '');
                if ($res['ok']) {
                    $this->flash('ok', 'Cliente actualizado.');
                    header('Location: index.php?url=clientes');
                    exit;
                }
                $error = $res['error'] ?? 'Error al actualizar.';
            }
        }

        // Desactivar / Activar
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['desactivar_cliente'])) {
            if (csrf_verify($_POST['csrf_token'] ?? '')) {
                $this->clienteModel->desactivar((int)($_POST['id'] ?? 0));
                $this->flash('ok', 'Cliente desactivado.');
            }
            header('Location: index.php?url=clientes');
            exit;
        }
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['activar_cliente'])) {
            if (csrf_verify($_POST['csrf_token'] ?? '')) {
                $this->clienteModel->activar((int)($_POST['id'] ?? 0));
                $this->flash('ok', 'Cliente reactivado.');
            }
            header('Location: index.php?url=clientes');
            exit;
        }

        $busqueda = trim($_GET['q'] ?? '');
        $orden = $_GET['orden'] ?? 'id';
        $dir = $_GET['dir'] ?? 'DESC';
        $page = max(1, (int)($_GET['page'] ?? 1));
        $lista = $this->clienteModel->listar($busqueda, $orden, $dir, $page, 10);
        $clientes = $lista['rows'];
        $paginacion = $lista;
        $editarId = isset($_GET['editar']) ? (int)$_GET['editar'] : null;
        $clienteEditar = $editarId ? $this->clienteModel->obtenerPorId($editarId) : null;

        require __DIR__ . '/../views/admin/clientes.php';
    }

    // =========================================================================
    // PEDIDOS — listado + registro con detalle y transacción
    // =========================================================================
    public function pedidos() {
        $this->proteger();
        exigirRol('admin', 'vendedor');

        $error = '';
        $flash = $this->takeFlash();

        // Nuevo pedido con detalle
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['crear_pedido'])) {
            if (!csrf_verify($_POST['csrf_token'] ?? '')) {
                $error = 'Token inválido.';
            } else {
                $clienteId = (int)($_POST['cliente_id'] ?? 0);
                $direccion = trim($_POST['direccion'] ?? '');
                $metodo = trim($_POST['metodo_pago'] ?? '');
                $ref = trim($_POST['referencia'] ?? '');
                $prodIds = $_POST['producto_id'] ?? [];
                $cants = $_POST['cantidad'] ?? [];
                $items = [];
                if (is_array($prodIds)) {
                    foreach ($prodIds as $i => $pid) {
                        $pid = (int)$pid;
                        $cant = (int)($cants[$i] ?? 0);
                        if ($pid > 0 && $cant > 0) {
                            $items[] = ['producto_id' => $pid, 'cantidad' => $cant];
                        }
                    }
                }
                if ($clienteId <= 0) {
                    $error = 'Selecciona un cliente.';
                } elseif (empty($items)) {
                    $error = 'Agrega al menos un producto con cantidad.';
                } else {
                    $res = $this->pedidoModel->crearConDetalle($clienteId, $items, $direccion, $metodo, $ref);
                    if ($res['ok']) {
                        $this->flash('ok', 'Pedido #' . $res['pedido_id'] . ' registrado. Total: $' . number_format($res['total'], 0));
                        header('Location: index.php?url=pedidos');
                        exit;
                    }
                    $error = $res['error'] ?? 'Error al registrar el pedido.';
                }
            }
        }

        $busqueda = trim($_GET['q'] ?? '');
        $page = max(1, (int)($_GET['page'] ?? 1));
        $lista = $this->pedidoModel->listar($busqueda, $page, 10);
        $pedidos = $lista['rows'];
        $paginacion = $lista;
        $clientesSelect = $this->clienteModel->listarSelect();
        $productosSelect = $this->inventarioModel->listar('', 'nombre_producto', 'ASC', 1, 200, true)['rows'];

        require __DIR__ . '/../views/admin/pedidos.php';
    }

    // =========================================================================
    // DASHBOARD + datos JSON para Chart.js desde vistas SQL
    // =========================================================================
    public function dashboard() {
        $this->proteger();
        exigirRol('admin', 'vendedor', 'consultor');

        require_once __DIR__ . '/../config/database.php';
        $db = (new Database())->getConnection();

        $sqlKpis = "
            SELECT
                (SELECT COUNT(*) FROM inventario WHERE activo = 1 OR activo IS NULL) AS productos_activos,
                (SELECT COUNT(*) FROM pedidos
                    WHERE YEAR(fecha_pedido) = YEAR(CURDATE())
                      AND MONTH(fecha_pedido) = MONTH(CURDATE())
                ) AS pedidos_mes,
                (SELECT COALESCE(SUM(total_pagado), 0) FROM pedidos
                    WHERE YEAR(fecha_pedido) = YEAR(CURDATE())
                      AND MONTH(fecha_pedido) = MONTH(CURDATE())
                ) AS ventas_mes,
                (SELECT COUNT(*) FROM inventario WHERE (activo = 1 OR activo IS NULL) AND cantidad <= COALESCE(stock_minimo, 5)) AS stock_critico
        ";
        $kpis = $db->query($sqlKpis)->fetch(PDO::FETCH_ASSOC) ?: [
            'productos_activos' => 0, 'pedidos_mes' => 0, 'ventas_mes' => 0, 'stock_critico' => 0,
        ];

        $stmtU = $db->query("SELECT id, nombre, correo, rol, creado_en FROM usuarios ORDER BY creado_en DESC, id DESC LIMIT 12");
        $usuariosRecientes = $stmtU ? $stmtU->fetchAll(PDO::FETCH_ASSOC) : [];
        $stmtTotalU = $db->query("SELECT COUNT(*) AS total FROM usuarios");
        $totalUsuarios = $stmtTotalU ? (int)$stmtTotalU->fetchColumn() : 0;

        $stmtP = $db->query("
            SELECT p.tipo_servicio, p.total_pagado, p.fecha_pedido, u.nombre AS cliente_nombre
            FROM pedidos p LEFT JOIN usuarios u ON u.id = p.usuario_id
            ORDER BY p.fecha_pedido DESC LIMIT 10
        ");
        $pedidosRecientes = $stmtP ? $stmtP->fetchAll(PDO::FETCH_ASSOC) : [];

        $stmtS = $db->query("
            SELECT id, nombre_producto, cantidad, precio FROM inventario
            WHERE (activo = 1 OR activo IS NULL) AND cantidad <= COALESCE(stock_minimo, 5)
            ORDER BY cantidad ASC LIMIT 15
        ");
        $stockCriticoLista = $stmtS ? $stmtS->fetchAll(PDO::FETCH_ASSOC) : [];

        // Datos desde vistas SQL para gráficos
        $ventasMes = [];
        $ventasCat = [];
        try {
            $ventasMes = $db->query("SELECT * FROM v_ventas_por_mes ORDER BY periodo ASC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Fallback si la vista no existe aún
            $ventasMes = $db->query("
                SELECT DATE_FORMAT(fecha_pedido, '%Y-%m') AS periodo,
                       DATE_FORMAT(fecha_pedido, '%b %Y') AS etiqueta,
                       COUNT(*) AS cantidad_pedidos,
                       COALESCE(SUM(total_pagado), 0) AS total_ventas
                FROM pedidos GROUP BY DATE_FORMAT(fecha_pedido, '%Y-%m'), DATE_FORMAT(fecha_pedido, '%b %Y')
                ORDER BY periodo ASC LIMIT 12
            ")->fetchAll(PDO::FETCH_ASSOC);
        }
        try {
            $ventasCat = $db->query("SELECT * FROM v_ventas_por_categoria")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $ventasCat = [];
        }

        $meses = [1=>'enero',2=>'febrero',3=>'marzo',4=>'abril',5=>'mayo',6=>'junio',
            7=>'julio',8=>'agosto',9=>'septiembre',10=>'octubre',11=>'noviembre',12=>'diciembre'];
        $periodoLabel = ($meses[(int)date('n')] ?? date('F')) . ' de ' . date('Y');

        require __DIR__ . '/../views/admin/dashboard.php';
    }

    /** Endpoint JSON para Chart.js (ventas por mes y por categoría) */
    public function apiGraficos() {
        $this->proteger();
        exigirRol('admin', 'vendedor', 'consultor');
        header('Content-Type: application/json; charset=utf-8');
        require_once __DIR__ . '/../config/database.php';
        $db = (new Database())->getConnection();
        $out = ['ventas_mes' => [], 'ventas_categoria' => [], 'stock_critico' => []];
        try {
            $out['ventas_mes'] = $db->query("SELECT * FROM v_ventas_por_mes ORDER BY periodo ASC")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $out['ventas_mes'] = $db->query("
                SELECT DATE_FORMAT(fecha_pedido, '%Y-%m') AS periodo, DATE_FORMAT(fecha_pedido, '%b %Y') AS etiqueta,
                       COUNT(*) AS cantidad_pedidos, COALESCE(SUM(total_pagado),0) AS total_ventas
                FROM pedidos GROUP BY 1,2 ORDER BY 1
            ")->fetchAll(PDO::FETCH_ASSOC);
        }
        try {
            $out['ventas_categoria'] = $db->query("SELECT * FROM v_ventas_por_categoria")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $out['ventas_categoria'] = [];
        }
        try {
            $out['stock_critico'] = $db->query("SELECT * FROM v_stock_critico LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $out['stock_critico'] = $db->query("
                SELECT id, nombre_producto, cantidad, COALESCE(stock_minimo,5) AS stock_minimo, precio
                FROM inventario WHERE cantidad <= COALESCE(stock_minimo,5) AND (activo=1 OR activo IS NULL)
                ORDER BY cantidad ASC LIMIT 20
            ")->fetchAll(PDO::FETCH_ASSOC);
        }
        echo json_encode($out, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // =========================================================================
    // CATEGORÍAS (vista existente mejorada)
    // =========================================================================
    public function categorias() {
        $this->proteger();
        exigirRol('admin', 'vendedor');
        require_once __DIR__ . '/../config/database.php';
        $db = (new Database())->getConnection();

        // Asegurar tabla
        try {
            $db->exec("CREATE TABLE IF NOT EXISTS categorias (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nombre VARCHAR(100) NOT NULL UNIQUE,
                descripcion VARCHAR(255) NULL,
                activo TINYINT(1) NOT NULL DEFAULT 1,
                creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB");
        } catch (PDOException $e) {}

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_categoria']) && csrf_verify($_POST['csrf_token'] ?? '')) {
            $nom = trim($_POST['nombre'] ?? '');
            if ($nom !== '') {
                try {
                    $stmt = $db->prepare("INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)");
                    $stmt->execute([$nom, trim($_POST['descripcion'] ?? '')]);
                    $this->flash('ok', 'Categoría creada.');
                } catch (PDOException $e) {
                    $this->flash('error', 'No se pudo crear (¿nombre duplicado?).');
                }
            }
            header('Location: index.php?url=categorias');
            exit;
        }

        $categoriasLista = [];
        try {
            $categoriasLista = $db->query("SELECT c.*, COUNT(i.id) AS num_productos
                FROM categorias c LEFT JOIN inventario i ON i.categoria_id = c.id
                GROUP BY c.id ORDER BY c.nombre")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $categoriasLista = [];
        }

        // Fallback agrupación por nombre (legacy)
        $productos = $db->query("SELECT id, nombre_producto, cantidad, precio FROM inventario ORDER BY nombre_producto")->fetchAll(PDO::FETCH_ASSOC);
        $categorias = [
            'Periféricos' => [], 'Pantallas / Consolas' => [], 'Almacenamiento' => [],
            'Móviles' => [], 'Audio' => [], 'Otros' => [],
        ];
        foreach ($productos as $p) {
            $n = mb_strtolower($p['nombre_producto']);
            if (str_contains($n, 'mouse') || str_contains($n, 'usb') || str_contains($n, 'teclado')) {
                $categorias['Periféricos'][] = $p;
            } elseif (str_contains($n, 'switch') || str_contains($n, 'xbox') || str_contains($n, 'playstation') || str_contains($n, 'ps5') || str_contains($n, 'consola') || str_contains($n, 'quest') || str_contains($n, 'laptop') || str_contains($n, 'rog')) {
                $categorias['Pantallas / Consolas'][] = $p;
            } elseif (str_contains($n, 'kingston') || str_contains($n, 'memoria')) {
                $categorias['Almacenamiento'][] = $p;
            } elseif (str_contains($n, 'iphone') || str_contains($n, 'samsung') || str_contains($n, 'motorola') || str_contains($n, 'galaxy')) {
                $categorias['Móviles'][] = $p;
            } elseif (str_contains($n, 'audífono') || str_contains($n, 'audifono') || str_contains($n, 'earbud') || str_contains($n, 'conducción') || str_contains($n, 'conduccion')) {
                $categorias['Audio'][] = $p;
            } else {
                $categorias['Otros'][] = $p;
            }
        }
        $flash = $this->takeFlash();
        require __DIR__ . '/../views/admin/categorias.php';
    }

    // =========================================================================
    // REPORTES — 3 reportes + export PDF/CSV + identidad visual
    // =========================================================================
    public function reportes() {
        $this->proteger();
        exigirRol('admin', 'consultor');
        require_once __DIR__ . '/../config/database.php';
        $db = (new Database())->getConnection();

        $tipo = $_GET['tipo'] ?? 'resumen';
        $filtroDesde = $_GET['desde'] ?? '';
        $filtroHasta = $_GET['hasta'] ?? '';

        // Datos base
        $porMes = [];
        $porCategoria = [];
        $stockCritico = [];
        $porCliente = [];
        $resumen = ['total_pedidos' => 0, 'total_ventas' => 0, 'promedio' => 0];

        try {
            $porMes = $db->query("SELECT * FROM v_ventas_por_mes ORDER BY periodo DESC LIMIT 12")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $porMes = $db->query("
                SELECT DATE_FORMAT(fecha_pedido, '%Y-%m') AS periodo, COUNT(*) AS cantidad_pedidos,
                       COALESCE(SUM(total_pagado),0) AS total_ventas
                FROM pedidos GROUP BY 1 ORDER BY 1 DESC LIMIT 12
            ")->fetchAll(PDO::FETCH_ASSOC);
        }
        try {
            $porCategoria = $db->query("SELECT * FROM v_ventas_por_categoria")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $porCategoria = [];
        }
        try {
            $stockCritico = $db->query("SELECT * FROM v_stock_critico")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $stockCritico = $db->query("
                SELECT id, nombre_producto, cantidad, COALESCE(stock_minimo,5) AS stock_minimo, precio,
                       'Sin categoría' AS categoria
                FROM inventario WHERE cantidad <= COALESCE(stock_minimo,5) AND (activo=1 OR activo IS NULL)
                ORDER BY cantidad ASC
            ")->fetchAll(PDO::FETCH_ASSOC);
        }
        try {
            $porCliente = $db->query("SELECT * FROM v_pedidos_por_cliente LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $porCliente = $db->query("
                SELECT u.id AS cliente_id, u.nombre AS cliente, u.correo, u.telefono,
                       COUNT(p.id) AS total_pedidos, COALESCE(SUM(p.total_pagado),0) AS total_gastado,
                       MAX(p.fecha_pedido) AS ultimo_pedido
                FROM usuarios u LEFT JOIN pedidos p ON p.usuario_id = u.id
                WHERE u.rol = 'cliente' GROUP BY u.id ORDER BY total_gastado DESC LIMIT 50
            ")->fetchAll(PDO::FETCH_ASSOC);
        }
        $resumen = $db->query("
            SELECT COUNT(*) AS total_pedidos, COALESCE(SUM(total_pagado),0) AS total_ventas,
                   COALESCE(AVG(total_pagado),0) AS promedio FROM pedidos
        ")->fetch(PDO::FETCH_ASSOC) ?: $resumen;

        $usuarioActual = $_SESSION['nombre'] ?? ($_SESSION['usuario_nombre'] ?? 'Usuario');
        $fechaReporte = date('d/m/Y H:i');

        // Export CSV
        if (isset($_GET['export']) && $_GET['export'] === 'csv') {
            $this->exportCsv($tipo, $porCategoria, $stockCritico, $porCliente);
            return;
        }

        require __DIR__ . '/../views/admin/reportes.php';
    }

    private function exportCsv($tipo, $porCategoria, $stockCritico, $porCliente) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="bytestock_reporte_' . $tipo . '_' . date('Ymd') . '.csv"');
        $out = fopen('php://output', 'w');
        fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM UTF-8

        if ($tipo === 'categoria') {
            fputcsv($out, ['Categoría', 'Pedidos', 'Total ventas', 'Unidades'], ';');
            foreach ($porCategoria as $r) {
                fputcsv($out, [
                    $r['categoria'] ?? '',
                    $r['cantidad_pedidos'] ?? 0,
                    $r['total_ventas'] ?? 0,
                    $r['unidades_vendidas'] ?? 0,
                ], ';');
            }
        } elseif ($tipo === 'stock') {
            fputcsv($out, ['ID', 'Producto', 'Cantidad', 'Stock mínimo', 'Precio', 'Categoría', 'Déficit'], ';');
            foreach ($stockCritico as $r) {
                fputcsv($out, [
                    $r['id'] ?? '',
                    $r['nombre_producto'] ?? '',
                    $r['cantidad'] ?? 0,
                    $r['stock_minimo'] ?? 5,
                    $r['precio'] ?? 0,
                    $r['categoria'] ?? '',
                    $r['deficit'] ?? 0,
                ], ';');
            }
        } else { // cliente
            fputcsv($out, ['Cliente', 'Correo', 'Teléfono', 'Pedidos', 'Total gastado', 'Último pedido'], ';');
            foreach ($porCliente as $r) {
                fputcsv($out, [
                    $r['cliente'] ?? '',
                    $r['correo'] ?? '',
                    $r['telefono'] ?? '',
                    $r['total_pedidos'] ?? 0,
                    $r['total_gastado'] ?? 0,
                    $r['ultimo_pedido'] ?? '',
                ], ';');
            }
        }
        fclose($out);
        exit;
    }

    public function usuarios() {
        $this->proteger();
        exigirRol('admin');
        require_once __DIR__ . '/../config/database.php';
        $db = (new Database())->getConnection();
        $usuarios = $db->query("
            SELECT id, nombre, correo, telefono, rol, creado_en
            FROM usuarios ORDER BY creado_en DESC, id DESC
        ")->fetchAll(PDO::FETCH_ASSOC);
        $reportesUsuarios = $db->query("
            SELECT u.id, u.nombre, u.correo, COUNT(p.id) AS pedidos,
                   COALESCE(SUM(p.total_pagado), 0) AS total_gastado, MAX(p.fecha_pedido) AS ultimo_pedido
            FROM usuarios u LEFT JOIN pedidos p ON p.usuario_id = u.id
            GROUP BY u.id, u.nombre, u.correo ORDER BY total_gastado DESC
        ")->fetchAll(PDO::FETCH_ASSOC);
        $stats = $db->query("
            SELECT COUNT(*) AS total,
                SUM(CASE WHEN rol = 'admin' THEN 1 ELSE 0 END) AS admins,
                SUM(CASE WHEN rol = 'cliente' OR rol IS NULL OR rol = '' THEN 1 ELSE 0 END) AS clientes
            FROM usuarios
        ")->fetch(PDO::FETCH_ASSOC);
        require __DIR__ . '/../views/admin/usuarios.php';
    }
}
?>
