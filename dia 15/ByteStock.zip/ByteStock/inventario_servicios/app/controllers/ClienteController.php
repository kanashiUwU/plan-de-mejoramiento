<?php
require_once __DIR__ . '/../models/InventarioModel.php';
require_once __DIR__ . '/../models/PedidoModel.php';

class ClienteController {
    private $inventarioModel;
    private $pedidoModel;

    public function __construct() {
        $this->inventarioModel = new InventarioModel();
        $this->pedidoModel = new PedidoModel();
    }

    /** Incluye el guardián (autenticación + inactividad + huella) */
    private function proteger(): void
    {
        require_once __DIR__ . '/../seguridad/guardia.php';
    }

    private function flash($tipo, $msg) {
        $_SESSION['flash'] = ['tipo' => $tipo, 'msg' => $msg];
    }

    private function takeFlash() {
        $f = $_SESSION['flash'] ?? null;
        unset($_SESSION['flash']);
        return $f;
    }

    public function solicitarServicio() {
        $this->proteger();
        // Cualquier usuario autenticado (admin o cliente) puede ver el catálogo y pedir
        exigirRol('admin', 'cliente');

        $error = null;
        $flash = $this->takeFlash();

        // Crear pedido desde el catálogo (cliente)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hacer_pedido'])) {
            if (!csrf_verify($_POST['csrf_token'] ?? '')) {
                $error = 'Token de seguridad inválido. Intenta de nuevo.';
            } else {
                $usuarioId = (int)($_SESSION['usuario']['id'] ?? 0);
                $productoId = (int)($_POST['producto_id'] ?? 0);
                $cantidad = (int)($_POST['cantidad'] ?? 0);
                $direccion = trim($_POST['direccion'] ?? '') ?: 'Sin especificar';
                $metodo = trim($_POST['metodo_pago'] ?? '') ?: 'Pendiente';
                $ref = trim($_POST['referencia'] ?? '') ?: '';

                if ($usuarioId <= 0) {
                    $error = 'Debes iniciar sesión para hacer un pedido.';
                } elseif ($productoId <= 0 || $cantidad <= 0) {
                    $error = 'Selecciona un producto y una cantidad válida.';
                } else {
                    $items = [['producto_id' => $productoId, 'cantidad' => $cantidad]];
                    $res = $this->pedidoModel->crearConDetalle(
                        $usuarioId,
                        $items,
                        $direccion,
                        $metodo,
                        $ref,
                        'pendiente'
                    );
                    if ($res['ok']) {
                        $this->flash('ok', 'Pedido #' . $res['pedido_id'] . ' realizado correctamente. Total: $' . number_format($res['total'], 0) . ' COP. El administrador lo verá en Pedidos.');
                        header('Location: index.php?url=solicitar_servicio');
                        exit;
                    }
                    $error = $res['error'] ?? 'No se pudo registrar el pedido.';
                }
            }
        }

        $busqueda = trim($_GET['q'] ?? '');
        $productos = $this->inventarioModel->obtenerTodos($busqueda);
        require_once __DIR__ . '/../views/cliente/solicitar_servicio.php';
    }
}
?>
