<?php
/**
 * Tablero / Dashboard funcional
 * Indicadores calculados con consultas reales a la base de datos.
 * Usa parciales: cabecera, menu, pie.
 */
declare(strict_types=1);

require __DIR__ . '/../parciales/cabecera.php';
?>

<div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-1">
    <div>
        <h1 class="section-title mb-0">Resumen general</h1>
        <p class="section-sub mb-0">
            Periodo: <?= htmlspecialchars($periodoLabel ?? date('F Y')) ?>
        </p>
    </div>
</div>

<!-- Tarjetas KPI -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card-kpi">
            <div class="kpi-label">Productos activos</div>
            <div class="kpi-value blue"><?= (int)($kpis['productos_activos'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card-kpi">
            <div class="kpi-label">Pedidos del mes</div>
            <div class="kpi-value green"><?= (int)($kpis['pedidos_mes'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card-kpi">
            <div class="kpi-label">Ventas del mes</div>
            <div class="kpi-value orange">
                $<?= number_format((float)($kpis['ventas_mes'] ?? 0) / 1000000, 1) ?> M
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card-kpi">
            <div class="kpi-label">Stock crítico</div>
            <div class="kpi-value red"><?= (int)($kpis['stock_critico'] ?? 0) ?></div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Usuarios recientes (cada nuevo registro aparece aquí) -->
    <div class="col-lg-6">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);font-weight:600;">
                👤 Usuarios registrados recientemente
            </h5>
            <div class="table-responsive">
                <table class="table table-dark-custom table-sm align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Rol</th>
                            <th>Registro</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($usuariosRecientes)): ?>
                            <tr><td colspan="5" class="text-muted text-center py-3">Sin usuarios aún</td></tr>
                        <?php else: foreach ($usuariosRecientes as $u): ?>
                            <tr>
                                <td><?= (int)$u['id'] ?></td>
                                <td><?= htmlspecialchars($u['nombre']) ?></td>
                                <td><small><?= htmlspecialchars($u['correo']) ?></small></td>
                                <td>
                                    <span class="badge <?= ($u['rol'] ?? '') === 'admin' ? 'bg-primary' : 'bg-secondary' ?>">
                                        <?= htmlspecialchars($u['rol'] ?? 'cliente') ?>
                                    </span>
                                </td>
                                <td><small><?= htmlspecialchars($u['creado_en'] ?? '') ?></small></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <p class="text-muted mt-2 mb-0" style="font-size:0.8rem;">
                Total de usuarios: <strong><?= (int)($totalUsuarios ?? 0) ?></strong>
            </p>
        </div>
    </div>

    <!-- Pedidos / reportes de clientes recientes -->
    <div class="col-lg-6">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);font-weight:600;">
                📊 Reportes / Pedidos recientes de clientes
            </h5>
            <div class="table-responsive">
                <table class="table table-dark-custom table-sm align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cliente</th>
                            <th>Total</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($pedidosRecientes)): ?>
                            <tr><td colspan="4" class="text-muted text-center py-3">Sin pedidos recientes</td></tr>
                        <?php else: foreach ($pedidosRecientes as $p): ?>
                            <tr>
                                <td><?= htmlspecialchars($p['tipo_servicio'] ?? $p['producto'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($p['cliente_nombre'] ?? $p['nombre'] ?? '-') ?></td>
                                <td>$<?= number_format((float)($p['total_pagado'] ?? 0), 0) ?></td>
                                <td><small><?= htmlspecialchars($p['fecha_pedido'] ?? '') ?></small></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Productos con stock bajo (crítico) -->
<div class="row g-4 mt-1">
    <div class="col-12">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);font-weight:600;">
                ⚠ Productos con stock crítico (&lt; 5 unidades)
            </h5>
            <div class="table-responsive">
                <table class="table table-dark-custom table-sm align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th>Stock</th>
                            <th>Precio</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($stockCriticoLista)): ?>
                            <tr><td colspan="4" class="text-muted text-center py-3">Ningún producto en stock crítico</td></tr>
                        <?php else: foreach ($stockCriticoLista as $prod): ?>
                            <tr>
                                <td><?= (int)$prod['id'] ?></td>
                                <td><?= htmlspecialchars($prod['nombre_producto'] ?? $prod['nombre'] ?? '') ?></td>
                                <td>
                                    <span class="badge bg-danger"><?= (int)($prod['cantidad'] ?? 0) ?></span>
                                </td>
                                <td>$<?= number_format((float)($prod['precio'] ?? 0), 0) ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Gráficos Chart.js desde vistas SQL -->
<div class="row g-4 mt-1">
    <div class="col-lg-6">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);font-weight:600;">📈 Ventas por mes (vista SQL)</h5>
            <canvas id="chartVentasMes" height="200"></canvas>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);font-weight:600;">🥧 Participación por categoría (vista SQL)</h5>
            <canvas id="chartVentasCat" height="200"></canvas>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
(function(){
    const ventasMes = <?= json_encode($ventasMes ?? [], JSON_UNESCAPED_UNICODE) ?>;
    const ventasCat = <?= json_encode($ventasCat ?? [], JSON_UNESCAPED_UNICODE) ?>;

    if (document.getElementById('chartVentasMes') && ventasMes.length) {
        new Chart(document.getElementById('chartVentasMes'), {
            type: 'line',
            data: {
                labels: ventasMes.map(r => r.etiqueta || r.periodo),
                datasets: [{
                    label: 'Ventas ($)',
                    data: ventasMes.map(r => parseFloat(r.total_ventas || 0)),
                    borderColor: '#38bdf8',
                    backgroundColor: 'rgba(56,189,248,0.15)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                scales: {
                    x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.1)' } },
                    y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(148,163,184,0.1)' } }
                },
                plugins: { legend: { labels: { color: '#cbd5e1' } } }
            }
        });
    }
    if (document.getElementById('chartVentasCat') && ventasCat.length) {
        new Chart(document.getElementById('chartVentasCat'), {
            type: 'doughnut',
            data: {
                labels: ventasCat.map(r => r.categoria),
                datasets: [{
                    data: ventasCat.map(r => parseFloat(r.total_ventas || 0)),
                    backgroundColor: ['#2563eb','#38bdf8','#6366f1','#22c55e','#f59e0b','#ef4444','#8b5cf6']
                }]
            },
            options: {
                plugins: { legend: { position: 'bottom', labels: { color: '#cbd5e1' } } }
            }
        });
    }
})();
</script>

<?php
require __DIR__ . '/../parciales/pie.php';
?>
