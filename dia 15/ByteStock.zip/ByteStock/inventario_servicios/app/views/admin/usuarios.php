<?php
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
?>
<h1 class="section-title">Usuarios</h1>
<p class="section-sub">
    Listado de usuarios registrados.
    Total: <strong><?= (int)($stats['total'] ?? 0) ?></strong>
    · Admins: <strong><?= (int)($stats['admins'] ?? 0) ?></strong>
    · Clientes: <strong><?= (int)($stats['clientes'] ?? 0) ?></strong>
</p>

<div class="card-kpi mb-4">
    <h5 style="color:var(--blue-soft);font-weight:600;margin-bottom:1rem;">👥 Todos los usuarios</h5>
    <div class="table-responsive">
        <table class="table table-dark-custom table-sm align-middle mb-0">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Teléfono</th>
                    <th>Rol</th>
                    <th>Registro</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($usuarios)): ?>
                    <tr><td colspan="6" class="text-muted text-center py-3">Sin usuarios</td></tr>
                <?php else: foreach ($usuarios as $u): ?>
                    <tr>
                        <td><?= (int)$u['id'] ?></td>
                        <td><?= htmlspecialchars($u['nombre']) ?></td>
                        <td><small><?= htmlspecialchars($u['correo']) ?></small></td>
                        <td><?= htmlspecialchars($u['telefono'] ?? '') ?></td>
                        <td>
                            <span class="badge <?= ($u['rol'] ?? '') === 'admin' ? 'bg-primary' : 'bg-secondary' ?>">
                                <?= htmlspecialchars($u['rol'] ?? 'cliente') ?>
                            </span>
                        </td>
                        <td><small><?= htmlspecialchars($u['creado_en'] ?? '') ?></small></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Apartado de reportes dentro de Usuarios -->
<div class="card-kpi">
    <h5 style="color:var(--blue-soft);font-weight:600;margin-bottom:1rem;">📊 Reportes por usuario (actividad de compras)</h5>
    <div class="table-responsive">
        <table class="table table-dark-custom table-sm align-middle mb-0">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Correo</th>
                    <th>Pedidos</th>
                    <th>Total gastado</th>
                    <th>Último pedido</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reportesUsuarios)): ?>
                    <tr><td colspan="5" class="text-muted text-center py-3">Sin datos de reportes</td></tr>
                <?php else: foreach ($reportesUsuarios as $r): ?>
                    <tr>
                        <td><?= htmlspecialchars($r['nombre']) ?></td>
                        <td><small><?= htmlspecialchars($r['correo']) ?></small></td>
                        <td><?= (int)$r['pedidos'] ?></td>
                        <td>$<?= number_format((float)$r['total_gastado'], 0) ?></td>
                        <td><small><?= htmlspecialchars($r['ultimo_pedido'] ?? '—') ?></small></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/../parciales/pie.php'; ?>
