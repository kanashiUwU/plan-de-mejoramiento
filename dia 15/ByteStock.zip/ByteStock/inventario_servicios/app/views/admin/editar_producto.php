<?php
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
?>
<h1 class="section-title">Editar producto</h1>
<p class="section-sub">Actualiza los datos del producto seleccionado.</p>
<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card-kpi p-4">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">Nombre *</label>
                    <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($producto['nombre_producto']) ?>" required maxlength="150">
                </div>
                <div class="mb-3">
                    <label class="form-label">Descripción</label>
                    <textarea name="descripcion" class="form-control" rows="3"><?= htmlspecialchars($producto['descripcion'] ?? '') ?></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Categoría</label>
                    <select name="categoria_id" class="form-select">
                        <option value="">— Sin categoría —</option>
                        <?php foreach (($categorias ?? []) as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= ((int)($producto['categoria_id'] ?? 0) === (int)$c['id']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($c['nombre']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Precio (COP) *</label>
                    <input type="number" name="precio" class="form-control" min="0" step="100" value="<?= htmlspecialchars((string)($producto['precio'] ?? 0)) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Cantidad *</label>
                    <input type="number" name="cantidad" class="form-control" value="<?= (int)$producto['cantidad'] ?>" min="0" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Stock mínimo (alerta)</label>
                    <input type="number" name="stock_minimo" class="form-control" min="0" value="<?= (int)($producto['stock_minimo'] ?? 5) ?>">
                </div>
                <div class="mb-4">
                    <label class="form-label">Ruta imagen</label>
                    <input type="text" name="imagen" class="form-control" value="<?= htmlspecialchars($producto['imagen'] ?? '') ?>" placeholder="assets/productos/ejemplo.jpg">
                </div>
                <button type="submit" class="btn btn-primary me-2">Actualizar producto</button>
                <a href="index.php?url=admin_inventario" class="btn btn-outline-light rounded-pill px-3">Cancelar</a>
            </form>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../parciales/pie.php'; ?>
