<?php
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
$q = htmlspecialchars($_GET['q'] ?? '');
$orden = htmlspecialchars($_GET['orden'] ?? 'id');
$dir = htmlspecialchars($_GET['dir'] ?? 'DESC');
$page = (int)($paginacion['page'] ?? 1);
$pages = (int)($paginacion['pages'] ?? 1);
$total = (int)($paginacion['total'] ?? 0);
?>
<h1 class="section-title">Clientes</h1>
<p class="section-sub">CRUD de clientes: crear, editar, desactivar. Búsqueda y paginación de 10.</p>

<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['tipo'] === 'ok' ? 'success' : 'danger' ?>"><?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>
<?php if (!empty($error)): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="GET" class="row g-2 mb-3">
    <input type="hidden" name="url" value="clientes">
    <div class="col-md-5"><input type="text" name="q" class="form-control" value="<?= $q ?>" placeholder="Buscar nombre, correo o teléfono..."></div>
    <div class="col-md-3">
        <select name="orden" class="form-select">
            <option value="id" <?= $orden==='id'?'selected':'' ?>>ID</option>
            <option value="nombre" <?= $orden==='nombre'?'selected':'' ?>>Nombre</option>
            <option value="total_pedidos" <?= $orden==='total_pedidos'?'selected':'' ?>>Pedidos</option>
            <option value="total_gastado" <?= $orden==='total_gastado'?'selected':'' ?>>Gastado</option>
        </select>
    </div>
    <div class="col-md-2">
        <select name="dir" class="form-select">
            <option value="ASC" <?= $dir==='ASC'?'selected':'' ?>>ASC</option>
            <option value="DESC" <?= $dir==='DESC'?'selected':'' ?>>DESC</option>
        </select>
    </div>
    <div class="col-md-2"><button class="btn btn-primary w-100">Filtrar</button></div>
</form>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);"><?= $clienteEditar ? 'Editar cliente' : 'Nuevo cliente' ?></h5>
            <form method="POST" action="index.php?url=clientes">
                <?= csrf_field() ?>
                <?php if ($clienteEditar): ?>
                <input type="hidden" name="editar_cliente" value="1">
                <input type="hidden" name="id" value="<?= (int)$clienteEditar['id'] ?>">
                <?php else: ?>
                <input type="hidden" name="crear_cliente" value="1">
                <?php endif; ?>
                <div class="mb-2">
                    <label class="form-label">Nombre *</label>
                    <input type="text" name="nombre" class="form-control" required
                           value="<?= htmlspecialchars($clienteEditar['nombre'] ?? '') ?>">
                </div>
                <div class="mb-2">
                    <label class="form-label">Correo *</label>
                    <input type="email" name="correo" class="form-control" required
                           value="<?= htmlspecialchars($clienteEditar['correo'] ?? '') ?>">
                </div>
                <div class="mb-2">
                    <label class="form-label">Teléfono</label>
                    <input type="text" name="telefono" class="form-control"
                           value="<?= htmlspecialchars($clienteEditar['telefono'] ?? '') ?>">
                </div>
                <?php if (!$clienteEditar): ?>
                <div class="mb-3">
                    <label class="form-label">Contraseña (opcional)</label>
                    <input type="text" name="password" class="form-control" placeholder="Se genera si se deja vacío">
                </div>
                <?php endif; ?>
                <button type="submit" class="btn btn-primary w-100"><?= $clienteEditar ? 'Actualizar' : 'Crear cliente' ?></button>
                <?php if ($clienteEditar): ?>
                <a href="index.php?url=clientes" class="btn btn-outline-secondary w-100 mt-2">Cancelar</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card-kpi">
            <p class="text-muted mb-2">Total: <?= $total ?> · Página <?= $page ?>/<?= $pages ?></p>
            <div class="table-responsive">
                <table class="table table-dark-custom table-sm align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th><th>Nombre</th><th>Correo</th><th>Teléfono</th>
                            <th>Pedidos</th><th>Gastado</th><th>Estado</th><th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clientes as $c): ?>
                        <tr class="<?= ((int)($c['activo'] ?? 1) === 0) ? 'opacity-50' : '' ?>">
                            <td><?= (int)$c['id'] ?></td>
                            <td><?= htmlspecialchars($c['nombre']) ?></td>
                            <td><small><?= htmlspecialchars($c['correo']) ?></small></td>
                            <td><?= htmlspecialchars($c['telefono'] ?? '') ?></td>
                            <td><?= (int)$c['total_pedidos'] ?></td>
                            <td>$<?= number_format((float)$c['total_gastado'], 0) ?></td>
                            <td>
                                <?php if ((int)($c['activo'] ?? 1) === 1): ?>
                                <span class="badge bg-success">Activo</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-nowrap">
                                <a href="index.php?url=clientes&editar=<?= (int)$c['id'] ?>" class="btn btn-warning btn-sm text-dark rounded-pill px-2">Editar</a>
                                <?php if ((int)($c['activo'] ?? 1) === 1): ?>
                                <form method="POST" class="d-inline" onsubmit="return confirm('¿Desactivar cliente?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <button type="submit" name="desactivar_cliente" value="1" class="btn btn-outline-danger btn-sm rounded-pill px-2">Desact.</button>
                                </form>
                                <?php else: ?>
                                <form method="POST" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <button type="submit" name="activar_cliente" value="1" class="btn btn-outline-success btn-sm rounded-pill px-2">Activar</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($clientes)): ?>
                        <tr><td colspan="8" class="text-center text-muted py-3">Sin clientes</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($pages > 1): ?>
            <nav class="mt-3">
                <ul class="pagination pagination-sm justify-content-center mb-0">
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="index.php?url=clientes&q=<?= urlencode($q) ?>&orden=<?= urlencode($orden) ?>&dir=<?= urlencode($dir) ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../parciales/pie.php'; ?>
