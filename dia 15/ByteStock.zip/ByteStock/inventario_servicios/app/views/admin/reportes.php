<?php
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
$tipo = $_GET['tipo'] ?? 'resumen';
$usuarioActual = $usuarioActual ?? ($_SESSION['nombre'] ?? 'Usuario');
$fechaReporte = $fechaReporte ?? date('d/m/Y H:i');
?>
<style>
@media print {
    .sidebar, .topbar, .no-print, .menu-lateral, nav, .btn, form { display: none !important; }
    .main-content, .content-area { margin: 0 !important; padding: 0 !important; width: 100% !important; }
    body { background: #fff !important; color: #000 !important; }
    .card-kpi { border: 1px solid #ccc; box-shadow: none; background: #fff !important; color: #000 !important; }
    .table { color: #000 !important; }
    .reporte-header { border-bottom: 2px solid #2563eb; margin-bottom: 1rem; padding-bottom: 0.5rem; }
}
.reporte-header { display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem; }
.reporte-header img { height: 48px; }
</style>

<div class="no-print">
    <h1 class="section-title">Reportes</h1>
    <p class="section-sub">Módulo de reportes con identidad visual ByteStock. Imprimible y exportable a CSV / PDF (impresión).</p>

    <div class="row g-2 mb-4">
        <div class="col-auto">
            <a href="index.php?url=reportes&tipo=categoria" class="btn btn-<?= $tipo==='categoria'?'primary':'outline-primary' ?>">Ventas por categoría</a>
        </div>
        <div class="col-auto">
            <a href="index.php?url=reportes&tipo=stock" class="btn btn-<?= $tipo==='stock'?'primary':'outline-primary' ?>">Inventario stock crítico</a>
        </div>
        <div class="col-auto">
            <a href="index.php?url=reportes&tipo=cliente" class="btn btn-<?= $tipo==='cliente'?'primary':'outline-primary' ?>">Pedidos por cliente</a>
        </div>
        <div class="col-auto">
            <a href="index.php?url=reportes&tipo=resumen" class="btn btn-<?= $tipo==='resumen'?'primary':'outline-primary' ?>">Resumen general</a>
        </div>
    </div>
</div>

<!-- Encabezado de identidad visual (visible también al imprimir) -->
<div class="card-kpi mb-4">
    <div class="reporte-header">
        <div style="width:48px;height:48px;background:linear-gradient(135deg,#2563eb,#38bdf8);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;font-size:1.2rem;">BS</div>
        <div>
            <h4 class="mb-0" style="color:var(--blue-soft);">ByteStock</h4>
            <small class="text-muted">Sistema de Inventario y Servicios · Reporte oficial</small>
        </div>
        <div class="ms-auto text-end">
            <div><strong>Fecha:</strong> <?= htmlspecialchars($fechaReporte) ?></div>
            <div><strong>Usuario:</strong> <?= htmlspecialchars($usuarioActual) ?></div>
        </div>
    </div>

    <?php if ($tipo === 'categoria'): ?>
    <h5 class="mb-3">Reporte: Ventas por categoría</h5>
    <div class="no-print mb-3">
        <a href="index.php?url=reportes&tipo=categoria&export=csv" class="btn btn-sm btn-success">Exportar CSV</a>
        <button onclick="window.print()" class="btn btn-sm btn-outline-light">Imprimir / PDF</button>
    </div>
    <div class="table-responsive">
        <table class="table table-dark-custom table-sm">
            <thead><tr><th>Categoría</th><th>Pedidos</th><th>Unidades</th><th>Total ventas</th></tr></thead>
            <tbody>
                <?php $sum = 0; foreach ($porCategoria as $r): $sum += (float)($r['total_ventas'] ?? 0); ?>
                <tr>
                    <td><?= htmlspecialchars($r['categoria'] ?? '') ?></td>
                    <td><?= (int)($r['cantidad_pedidos'] ?? 0) ?></td>
                    <td><?= (int)($r['unidades_vendidas'] ?? 0) ?></td>
                    <td>$<?= number_format((float)($r['total_ventas'] ?? 0), 0) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($porCategoria)): ?>
                <tr><td colspan="4" class="text-muted text-center">Sin datos (importe el schema completo y registre pedidos con detalle)</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot><tr><th colspan="3">Total</th><th>$<?= number_format($sum, 0) ?></th></tr></tfoot>
        </table>
    </div>
    <div class="no-print mt-3" style="max-width:400px;margin:auto;">
        <canvas id="chartCat"></canvas>
    </div>

    <?php elseif ($tipo === 'stock'): ?>
    <h5 class="mb-3">Reporte: Inventario con stock crítico</h5>
    <div class="no-print mb-3">
        <a href="index.php?url=reportes&tipo=stock&export=csv" class="btn btn-sm btn-success">Exportar CSV</a>
        <button onclick="window.print()" class="btn btn-sm btn-outline-light">Imprimir / PDF</button>
    </div>
    <div class="table-responsive">
        <table class="table table-dark-custom table-sm">
            <thead><tr><th>ID</th><th>Producto</th><th>Cantidad</th><th>Mínimo</th><th>Déficit</th><th>Precio</th><th>Categoría</th></tr></thead>
            <tbody>
                <?php foreach ($stockCritico as $r): ?>
                <tr>
                    <td><?= (int)($r['id'] ?? 0) ?></td>
                    <td><?= htmlspecialchars($r['nombre_producto'] ?? '') ?></td>
                    <td class="text-danger fw-bold"><?= (int)($r['cantidad'] ?? 0) ?></td>
                    <td><?= (int)($r['stock_minimo'] ?? 5) ?></td>
                    <td><?= (int)($r['deficit'] ?? max(0, ($r['stock_minimo'] ?? 5) - ($r['cantidad'] ?? 0))) ?></td>
                    <td>$<?= number_format((float)($r['precio'] ?? 0), 0) ?></td>
                    <td><?= htmlspecialchars($r['categoria'] ?? '') ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($stockCritico)): ?>
                <tr><td colspan="7" class="text-muted text-center">No hay productos en stock crítico</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php elseif ($tipo === 'cliente'): ?>
    <h5 class="mb-3">Reporte: Pedidos por cliente</h5>
    <div class="no-print mb-3">
        <a href="index.php?url=reportes&tipo=cliente&export=csv" class="btn btn-sm btn-success">Exportar CSV</a>
        <button onclick="window.print()" class="btn btn-sm btn-outline-light">Imprimir / PDF</button>
    </div>
    <div class="table-responsive">
        <table class="table table-dark-custom table-sm">
            <thead><tr><th>Cliente</th><th>Correo</th><th>Teléfono</th><th>Pedidos</th><th>Total gastado</th><th>Último pedido</th></tr></thead>
            <tbody>
                <?php $sumG = 0; foreach ($porCliente as $r): $sumG += (float)($r['total_gastado'] ?? 0); ?>
                <tr>
                    <td><?= htmlspecialchars($r['cliente'] ?? '') ?></td>
                    <td><small><?= htmlspecialchars($r['correo'] ?? '') ?></small></td>
                    <td><?= htmlspecialchars($r['telefono'] ?? '') ?></td>
                    <td><?= (int)($r['total_pedidos'] ?? 0) ?></td>
                    <td>$<?= number_format((float)($r['total_gastado'] ?? 0), 0) ?></td>
                    <td><small><?= htmlspecialchars($r['ultimo_pedido'] ?? '—') ?></small></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($porCliente)): ?>
                <tr><td colspan="6" class="text-muted text-center">Sin datos</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot><tr><th colspan="4">Total general</th><th>$<?= number_format($sumG, 0) ?></th><th></th></tr></tfoot>
        </table>
    </div>

    <?php else: /* resumen */ ?>
    <h5 class="mb-3">Resumen general de ventas</h5>
    <div class="row g-3 mb-4">
        <div class="col-md-4"><div class="kpi-label">Total pedidos</div><div class="kpi-value blue"><?= (int)($resumen['total_pedidos'] ?? 0) ?></div></div>
        <div class="col-md-4"><div class="kpi-label">Ventas totales</div><div class="kpi-value orange">$<?= number_format((float)($resumen['total_ventas'] ?? 0), 0) ?></div></div>
        <div class="col-md-4"><div class="kpi-label">Ticket promedio</div><div class="kpi-value green">$<?= number_format((float)($resumen['promedio'] ?? 0), 0) ?></div></div>
    </div>
    <div class="no-print mb-3">
        <button onclick="window.print()" class="btn btn-sm btn-outline-light">Imprimir / PDF</button>
    </div>
    <h6>Ventas por mes</h6>
    <div class="table-responsive mb-4">
        <table class="table table-dark-custom table-sm">
            <thead><tr><th>Periodo</th><th>Pedidos</th><th>Total</th></tr></thead>
            <tbody>
                <?php foreach ($porMes as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['periodo'] ?? $r['etiqueta'] ?? '') ?></td>
                    <td><?= (int)($r['cantidad_pedidos'] ?? $r['cantidad'] ?? 0) ?></td>
                    <td>$<?= number_format((float)($r['total_ventas'] ?? $r['total'] ?? 0), 0) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($porMes)): ?><tr><td colspan="3" class="text-muted text-center">Sin datos</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="no-print" style="max-width:500px;margin:auto;">
        <canvas id="chartMes"></canvas>
    </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
<?php if ($tipo === 'categoria' && !empty($porCategoria)): ?>
new Chart(document.getElementById('chartCat'), {
    type: 'pie',
    data: {
        labels: <?= json_encode(array_column($porCategoria, 'categoria')) ?>,
        datasets: [{
            data: <?= json_encode(array_map('floatval', array_column($porCategoria, 'total_ventas'))) ?>,
            backgroundColor: ['#2563eb','#38bdf8','#6366f1','#22c55e','#f59e0b','#ef4444','#8b5cf6']
        }]
    },
    options: { plugins: { legend: { labels: { color: '#cbd5e1' } } } }
});
<?php endif; ?>
<?php if ($tipo === 'resumen' && !empty($porMes)): ?>
new Chart(document.getElementById('chartMes'), {
    type: 'bar',
    data: {
        labels: <?= json_encode(array_map(fn($r) => $r['periodo'] ?? $r['etiqueta'] ?? '', $porMes)) ?>,
        datasets: [{
            label: 'Ventas',
            data: <?= json_encode(array_map(fn($r) => (float)($r['total_ventas'] ?? $r['total'] ?? 0), $porMes)) ?>,
            backgroundColor: 'rgba(37,99,235,0.8)'
        }]
    },
    options: {
        scales: { x: { ticks: { color: '#94a3b8' } }, y: { ticks: { color: '#94a3b8' } } },
        plugins: { legend: { labels: { color: '#cbd5e1' } } }
    }
});
<?php endif; ?>
</script>
<?php require __DIR__ . '/../parciales/pie.php'; ?>
