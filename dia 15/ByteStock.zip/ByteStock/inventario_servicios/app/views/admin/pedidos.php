<?php
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
$q = htmlspecialchars($_GET['q'] ?? '');
$page = (int)($paginacion['page'] ?? 1);
$pages = (int)($paginacion['pages'] ?? 1);
$total = (int)($paginacion['total'] ?? 0);
?>
<h1 class="section-title">Pedidos</h1>
<p class="section-sub">Registro de pedidos con detalle y descuento automático de stock (transacción).</p>

<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['tipo'] === 'ok' ? 'success' : 'danger' ?>"><?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>
<?php if (!empty($error)): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="row g-4 mb-4">
    <div class="col-lg-5">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);">🛒 Pedido del producto</h5>
            <form method="POST" action="index.php?url=pedidos" id="formPedido">
                <?= csrf_field() ?>
                <input type="hidden" name="crear_pedido" value="1">
                <div class="mb-2">
                    <label class="form-label">Cliente *</label>
                    <select name="cliente_id" class="form-select" required>
                        <option value="">— Seleccionar —</option>
                        <?php foreach (($clientesSelect ?? []) as $cl): ?>
                        <option value="<?= (int)$cl['id'] ?>"><?= htmlspecialchars($cl['nombre'] . ' (' . $cl['correo'] . ')') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="form-label">Dirección</label>
                    <input type="text" name="direccion" class="form-control">
                </div>
                <div class="mb-2">
                    <label class="form-label">Método de pago</label>
                    <select name="metodo_pago" class="form-select">
                        <option value="Efectivo">Efectivo</option>
                        <option value="Transferencia">Transferencia</option>
                        <option value="Tarjeta">Tarjeta</option>
                        <option value="Nequi">Nequi</option>
                        <option value="Daviplata">Daviplata</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Referencia pago</label>
                    <input type="text" name="referencia" class="form-control">
                </div>
                <hr>
                <label class="form-label">Productos (agrega líneas)</label>
                <div id="lineas">
                    <div class="row g-2 mb-2 linea-item">
                        <div class="col-7">
                            <select name="producto_id[]" class="form-select form-select-sm" required>
                                <option value="">Producto...</option>
                                <?php foreach (($productosSelect ?? []) as $pr): ?>
                                <option value="<?= (int)$pr['id'] ?>" data-precio="<?= (float)$pr['precio'] ?>" data-stock="<?= (int)$pr['cantidad'] ?>">
                                    <?= htmlspecialchars($pr['nombre_producto']) ?> (stock: <?= (int)$pr['cantidad'] ?>) — $<?= number_format((float)$pr['precio'], 0) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-3">
                            <input type="number" name="cantidad[]" class="form-control form-control-sm" min="1" value="1" required>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn btn-sm btn-outline-danger w-100" onclick="this.closest('.linea-item').remove()">×</button>
                        </div>
                    </div>
                </div>
                <button type="button" class="btn btn-sm btn-outline-primary mb-3" onclick="agregarLinea()">+ Agregar línea</button>
                <button type="submit" class="btn btn-primary w-100">Registrar pedido y descontar stock</button>
            </form>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card-kpi">
            <h5 class="mb-3" style="color:var(--blue-soft);">🔍 Consulta de productos / pedidos</h5>
            <form method="GET" class="mb-3 row g-2">
                <input type="hidden" name="url" value="pedidos">
                <div class="col-9"><input type="text" name="q" class="form-control" value="<?= $q ?>" placeholder="Buscar..."></div>
                <div class="col-3"><button class="btn btn-primary w-100">Buscar</button></div>
            </form>
            <p class="text-muted">Total: <?= $total ?> · Página <?= $page ?>/<?= $pages ?></p>
            <div class="table-responsive">
                <table class="table table-dark-custom table-sm align-middle mb-0">
                    <thead>
                        <tr><th>#</th><th>Cliente</th><th>Resumen</th><th>Total</th><th>Pago</th><th>Estado</th><th>Fecha</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos as $p): ?>
                        <?php
                            $est = $p['estado'] ?? 'completado';
                            $badgeClass = $est === 'pendiente' ? 'bg-warning text-dark' : ($est === 'cancelado' ? 'bg-danger' : 'bg-success');
                        ?>
                        <tr>
                            <td><?= (int)$p['id'] ?></td>
                            <td><?= htmlspecialchars($p['cliente_nombre'] ?? '—') ?></td>
                            <td><small><?= htmlspecialchars($p['tipo_servicio']) ?></small></td>
                            <td>$<?= number_format((float)$p['total_pagado'], 0) ?></td>
                            <td><?= htmlspecialchars($p['metodo_pago'] ?? '—') ?></td>
                            <td><span class="badge <?= $badgeClass ?>"><?= htmlspecialchars(ucfirst($est)) ?></span></td>
                            <td><small><?= htmlspecialchars($p['fecha_pedido']) ?></small></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($pedidos)): ?>
                        <tr><td colspan="7" class="text-center text-muted">Sin pedidos</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($pages > 1): ?>
            <nav class="mt-3">
                <ul class="pagination pagination-sm justify-content-center mb-0">
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="index.php?url=pedidos&q=<?= urlencode($q) ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
function agregarLinea() {
    const cont = document.getElementById('lineas');
    const primera = cont.querySelector('.linea-item');
    const clone = primera.cloneNode(true);
    clone.querySelectorAll('input').forEach(i => { if (i.type === 'number') i.value = 1; });
    clone.querySelector('select').selectedIndex = 0;
    cont.appendChild(clone);
}
</script>
<?php require __DIR__ . '/../parciales/pie.php'; ?>
