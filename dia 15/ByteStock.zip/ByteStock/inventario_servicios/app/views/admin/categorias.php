<?php
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
?>
<h1 class="section-title">Categorías</h1>
<p class="section-sub">Productos agrupados por categoría (inferida del inventario).</p>

<div class="row g-3">
<?php foreach ($categorias as $nombreCat => $items): ?>
    <?php if (empty($items)) continue; ?>
    <div class="col-md-6 col-lg-4">
        <div class="card-kpi h-100">
            <h5 style="color:var(--blue-soft);font-weight:600;margin-bottom:0.75rem;">
                <?= htmlspecialchars($nombreCat) ?>
                <span class="badge bg-primary ms-1"><?= count($items) ?></span>
            </h5>
            <ul class="list-unstyled mb-0" style="font-size:0.9rem;">
                <?php foreach ($items as $p): ?>
                    <li class="d-flex justify-content-between py-1 border-bottom" style="border-color:rgba(59,130,246,0.15)!important;">
                        <span><?= htmlspecialchars($p['nombre_producto']) ?></span>
                        <span class="text-muted">x<?= (int)$p['cantidad'] ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php endforeach; ?>
</div>
<?php require __DIR__ . '/../parciales/pie.php'; ?>
