<?php
/**
 * Inventario / Productos — CRUD completo: búsqueda, paginación 10, orden, validación PHP.
 */
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
$puedeEscribir = function_exists('puede') ? puede('admin', 'vendedor') : true;
$q = htmlspecialchars($_GET['q'] ?? '');
$orden = htmlspecialchars($_GET['orden'] ?? 'id');
$dir = htmlspecialchars($_GET['dir'] ?? 'DESC');
$page = (int)($paginacion['page'] ?? 1);
$pages = (int)($paginacion['pages'] ?? 1);
$total = (int)($paginacion['total'] ?? 0);
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<h1 class="section-title">Productos</h1>
<p class="section-sub">Gestiona el catálogo, stock y precios. Búsqueda, paginación y ordenamiento.</p>

<?php if (!empty($flash)): ?>
<div class="alert alert-<?= $flash['tipo'] === 'ok' ? 'success' : 'danger' ?>"><?= htmlspecialchars($flash['msg']) ?></div>
<?php endif; ?>
<?php if (!empty($error)): ?>
<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<div class="row mb-4 g-3">
    <div class="col-md-4">
        <div class="card-kpi">
            <div class="kpi-label">Productos en catálogo</div>
            <div class="kpi-value blue"><?= (int)$totalProductos ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-kpi">
            <div class="kpi-label">Unidades en stock</div>
            <div class="kpi-value green"><?= (int)$totalUnidades ?></div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card-kpi">
            <div class="kpi-label">Ventas totales</div>
            <div class="kpi-value orange"><?= (int)$totalVentas ?> · $<?= number_format((float)$totalGanancias, 0) ?></div>
        </div>
    </div>
</div>

<!-- Búsqueda y orden -->
<form method="GET" class="row g-2 mb-3 align-items-end">
    <input type="hidden" name="url" value="admin_inventario">
    <div class="col-md-4">
        <label class="form-label">Buscar</label>
        <input type="text" name="q" class="form-control" value="<?= $q ?>" placeholder="Nombre o descripción...">
    </div>
    <div class="col-md-3">
        <label class="form-label">Ordenar por</label>
        <select name="orden" class="form-select">
            <option value="id" <?= $orden==='id'?'selected':'' ?>>ID</option>
            <option value="nombre_producto" <?= $orden==='nombre_producto'?'selected':'' ?>>Nombre</option>
            <option value="cantidad" <?= $orden==='cantidad'?'selected':'' ?>>Stock</option>
            <option value="precio" <?= $orden==='precio'?'selected':'' ?>>Precio</option>
            <option value="categoria" <?= $orden==='categoria'?'selected':'' ?>>Categoría</option>
        </select>
    </div>
    <div class="col-md-2">
        <label class="form-label">Dirección</label>
        <select name="dir" class="form-select">
            <option value="ASC" <?= $dir==='ASC'?'selected':'' ?>>Ascendente</option>
            <option value="DESC" <?= $dir==='DESC'?'selected':'' ?>>Descendente</option>
        </select>
    </div>
    <div class="col-md-3">
        <button type="submit" class="btn btn-primary w-100">Filtrar</button>
    </div>
</form>

<div class="row g-4">
    <?php if ($puedeEscribir): ?>
    <div class="col-md-4">
        <div class="card-kpi">
            <h4 class="mb-3" style="color:var(--blue-soft);font-size:1.1rem;">Añadir producto</h4>
            <form method="POST" action="index.php?url=admin_inventario">
                <?= csrf_field() ?>
                <input type="hidden" name="agregar" value="1">
                <div class="mb-2">
                    <label class="form-label">Nombre *</label>
                    <input type="text" name="nombre" class="form-control" required maxlength="150">
                </div>
                <div class="mb-2">
                    <label class="form-label">Descripción</label>
                    <textarea name="descripcion" class="form-control" rows="2"></textarea>
                </div>
                <div class="mb-2">
                    <label class="form-label">Categoría</label>
                    <select name="categoria_id" class="form-select">
                        <option value="">— Sin categoría —</option>
                        <?php foreach (($categorias ?? []) as $c): ?>
                        <option value="<?= (int)$c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="form-label">Precio (COP) *</label>
                    <input type="number" name="precio" class="form-control" min="0" step="100" value="0" required>
                </div>
                <div class="mb-2">
                    <label class="form-label">Cantidad en stock *</label>
                    <input type="number" name="cantidad" class="form-control" min="0" required>
                </div>
                <div class="mb-2">
                    <label class="form-label">Stock mínimo (alerta)</label>
                    <input type="number" name="stock_minimo" class="form-control" min="0" value="5">
                </div>
                <div class="mb-3">
                    <label class="form-label">Ruta imagen (opcional)</label>
                    <input type="text" name="imagen" class="form-control" placeholder="assets/productos/ejemplo.jpg">
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2">Guardar producto</button>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <div class="<?= $puedeEscribir ? 'col-md-8' : 'col-md-12' ?>">
        <div class="card-kpi">
            <div class="d-flex justify-content-between mb-2">
                <span class="text-muted">Mostrando <?= count($productos) ?> de <?= $total ?> (página <?= $page ?>/<?= $pages ?>)</span>
            </div>
            <div class="table-responsive">
                <table class="table table-dark-custom table-bordered align-middle mb-0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th>Categoría</th>
                            <th>Stock</th>
                            <th>Precio</th>
                            <th>Estado</th>
                            <?php if ($puedeEscribir): ?><th>Acciones</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($productos as $prod): ?>
                        <tr class="<?= ((int)($prod['activo'] ?? 1) === 0) ? 'opacity-50' : '' ?>">
                            <td><?= (int)$prod['id'] ?></td>
                            <td>
                                <strong><?= htmlspecialchars($prod['nombre_producto']) ?></strong>
                                <?php if ((int)$prod['cantidad'] <= (int)($prod['stock_minimo'] ?? 5)): ?>
                                <span class="badge bg-danger">Crítico</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($prod['categoria_nombre'] ?? '—') ?></td>
                            <td><?= (int)$prod['cantidad'] ?></td>
                            <td>$<?= number_format((float)$prod['precio'], 0) ?></td>
                            <td>
                                <?php if ((int)($prod['activo'] ?? 1) === 1): ?>
                                <span class="badge bg-success">Activo</span>
                                <?php else: ?>
                                <span class="badge bg-secondary">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <?php if ($puedeEscribir): ?>
                            <td class="text-nowrap">
                                <a href="index.php?url=admin_editar_producto&id=<?= (int)$prod['id'] ?>" class="btn btn-warning btn-sm text-dark fw-bold rounded-pill px-2">Editar</a>
                                <?php if ((int)($prod['activo'] ?? 1) === 1): ?>
                                <form method="POST" action="index.php?url=admin_inventario" class="d-inline" onsubmit="return confirm('¿Desactivar este producto?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= (int)$prod['id'] ?>">
                                    <button type="submit" name="desactivar_producto" value="1" class="btn btn-outline-danger btn-sm rounded-pill px-2">Desactivar</button>
                                </form>
                                <?php else: ?>
                                <form method="POST" action="index.php?url=admin_inventario" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="id" value="<?= (int)$prod['id'] ?>">
                                    <button type="submit" name="activar_producto" value="1" class="btn btn-outline-success btn-sm rounded-pill px-2">Activar</button>
                                </form>
                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($productos)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">No hay productos.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- Paginación -->
            <?php if ($pages > 1): ?>
            <nav class="mt-3">
                <ul class="pagination pagination-sm justify-content-center mb-0">
                    <?php for ($i = 1; $i <= $pages; $i++): ?>
                    <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                        <a class="page-link" href="index.php?url=admin_inventario&q=<?= urlencode($q) ?>&orden=<?= urlencode($orden) ?>&dir=<?= urlencode($dir) ?>&page=<?= $i ?>"><?= $i ?></a>
                    </li>
                    <?php endfor; ?>
                </ul>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../parciales/pie.php'; ?>
