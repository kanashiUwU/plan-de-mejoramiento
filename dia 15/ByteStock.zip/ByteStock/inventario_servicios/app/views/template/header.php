<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteStock - Tecnología e Inventario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --bg-deep: #050810;
            --bg-card: rgba(12, 20, 40, 0.72);
            --blue-glow: #3b82f6;
            --blue-bright: #60a5fa;
            --blue-soft: #93c5fd;
            --border-glow: rgba(59, 130, 246, 0.35);
            --text-main: #e8f0fe;
            --text-muted: #94a3b8;
        }

        * { box-sizing: border-box; }

        body {
            background: radial-gradient(ellipse at top, #0c1a35 0%, #050810 55%, #020408 100%);
            color: var(--text-main);
            font-family: 'Inter', system-ui, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* ===== NIEVE FLOTANTE ===== */
        .snow-layer {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 9999;
            overflow: hidden;
        }
        .snowflake {
            position: absolute;
            top: -12px;
            color: #fff;
            font-size: 10px;
            opacity: 0.7;
            animation: snowfall linear infinite;
            text-shadow: 0 0 6px rgba(147, 197, 253, 0.8);
            user-select: none;
        }
        @keyframes snowfall {
            0%   { transform: translateY(-10vh) translateX(0) rotate(0deg); opacity: 0; }
            10%  { opacity: 0.85; }
            90%  { opacity: 0.6; }
            100% { transform: translateY(110vh) translateX(40px) rotate(360deg); opacity: 0; }
        }

        /* Navbar premium */
        .navbar-bytestock {
            background: linear-gradient(90deg, rgba(15, 30, 70, 0.95), rgba(20, 50, 120, 0.9)) !important;
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--border-glow);
            box-shadow: 0 4px 30px rgba(59, 130, 246, 0.15);
        }
        .navbar-brand {
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 1px;
            background: linear-gradient(90deg, #60a5fa, #a5b4fc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 700;
        }

        .btn-bytestock {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
            transition: all 0.25s ease;
        }
        .btn-bytestock:hover {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5);
        }

        .btn-outline-bytestock {
            border: 1px solid var(--blue-bright);
            color: var(--blue-bright);
            border-radius: 10px;
        }
        .btn-outline-bytestock:hover {
            background: rgba(59, 130, 246, 0.2);
            color: #fff;
            border-color: var(--blue-bright);
        }

        /* Cards glassmorphism */
        .card {
            background: var(--bg-card) !important;
            border: 1px solid var(--border-glow);
            border-radius: 16px;
            color: var(--text-main);
            backdrop-filter: blur(16px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255,255,255,0.05);
            transition: transform 0.25s ease, box-shadow 0.25s ease;
        }
        .card:hover {
            box-shadow: 0 12px 40px rgba(59, 130, 246, 0.2), inset 0 1px 0 rgba(255,255,255,0.08);
        }
        .card-body, .card.bg-white {
            background: transparent !important;
            color: var(--text-main);
        }

        .text-primary-byte {
            color: var(--blue-bright) !important;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: 0.5px;
        }

        .table {
            color: var(--text-main);
            --bs-table-bg: transparent;
            --bs-table-striped-bg: rgba(30, 50, 90, 0.35);
            --bs-table-border-color: rgba(59, 130, 246, 0.2);
            --bs-table-hover-bg: rgba(59, 130, 246, 0.12);
        }
        .table-dark {
            --bs-table-bg: linear-gradient(90deg, #1e3a8a, #1d4ed8);
            background: linear-gradient(90deg, #1e3a8a, #1d4ed8) !important;
            --bs-table-color: #fff;
            border-color: transparent;
        }
        .table thead th {
            border: none;
            font-weight: 600;
            letter-spacing: 0.3px;
        }

        .form-control, .form-select {
            background-color: rgba(8, 15, 30, 0.8);
            border: 1px solid rgba(59, 130, 246, 0.3);
            color: var(--text-main);
            border-radius: 10px;
        }
        .form-control:focus, .form-select:focus {
            background-color: rgba(10, 20, 40, 0.95);
            border-color: var(--blue-glow);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .form-control::placeholder { color: #64748b; }

        .text-muted { color: var(--text-muted) !important; }

        .alert-success {
            background: rgba(16, 185, 129, 0.15);
            border: 1px solid rgba(16, 185, 129, 0.4);
            color: #6ee7b7;
            border-radius: 12px;
        }
        .alert-danger {
            background: rgba(239, 68, 68, 0.15);
            border: 1px solid rgba(239, 68, 68, 0.4);
            color: #fca5a5;
            border-radius: 12px;
        }

        h1, h2, h3, h4, h5 { color: var(--text-main); }
        a { color: var(--blue-soft); }
        a:hover { color: #bfdbfe; }

        .border-primary-byte {
            border-color: var(--blue-glow) !important;
        }

        /* Stat cards glow */
        .stat-card {
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.1);
            position: relative;
            overflow: hidden;
        }
        .stat-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(255,255,255,0.08) 0%, transparent 60%);
            pointer-events: none;
        }

        /* Product cards hover lift */
        .product-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .product-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 16px 40px rgba(59, 130, 246, 0.25);
        }

        .badge-catalog {
            background: linear-gradient(135deg, #1e40af, #3b82f6);
            border-radius: 20px;
            padding: 0.35em 0.85em;
            font-weight: 500;
        }

        .price-tag {
            color: #7dd3fc;
            text-shadow: 0 0 20px rgba(125, 211, 252, 0.4);
        }
    </style>
</head>
<body>
    <!-- Capa de nieve (siempre visible) -->
    <div class="snow-layer" id="snowLayer" aria-hidden="true"></div>
    <script>
    (function() {
        const layer = document.getElementById('snowLayer');
        if (!layer) return;
        const count = 55;
        for (let i = 0; i < count; i++) {
            const flake = document.createElement('span');
            flake.className = 'snowflake';
            flake.textContent = '❄';
            flake.style.left = Math.random() * 100 + '%';
            flake.style.fontSize = (6 + Math.random() * 12) + 'px';
            flake.style.animationDuration = (8 + Math.random() * 14) + 's';
            flake.style.animationDelay = (Math.random() * 10) + 's';
            flake.style.opacity = 0.35 + Math.random() * 0.55;
            layer.appendChild(flake);
        }
    })();
    </script>

    <nav class="navbar navbar-expand-lg navbar-dark navbar-bytestock shadow-sm mb-4">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">💻 ByteStock</a>
            <div class="navbar-nav ms-auto">
                <?php if (!empty($_SESSION['usuario']['id'])): ?>
                    <?php
                        $nombreUsuario = htmlspecialchars($_SESSION['usuario']['nombre'] ?? '', ENT_QUOTES, 'UTF-8');
                        $rolUsuario    = htmlspecialchars($_SESSION['usuario']['rol'] ?? '', ENT_QUOTES, 'UTF-8');
                        $etiquetaRol   = $rolUsuario === 'admin' ? 'Administrador' : 'Cliente';
                        if ($rolUsuario === 'admin') {
                            $nombreUsuario = 'Administrador';
                        }
                    ?>
                    <span class="navbar-text text-white me-3">
                        Bienvenido, <strong><?= $nombreUsuario ?></strong>
                        <span class="badge bg-primary ms-1"><?= $etiquetaRol ?></span>
                    </span>
                    <a class="btn btn-outline-light btn-sm rounded-pill px-3" href="index.php?url=logout">Cerrar Sesión</a>
                <?php else: ?>
                    <a class="nav-link text-white" href="index.php?url=login">Iniciar Sesión</a>
                    <a class="nav-link text-white" href="index.php?url=registro">Registrarse</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container">
