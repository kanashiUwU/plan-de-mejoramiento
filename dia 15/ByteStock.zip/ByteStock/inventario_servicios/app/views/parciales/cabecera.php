<?php
/**
 * Cabecera común del panel (parcial).
 * Incluye estilos del tema azul/negro con efecto nublado + nieve flotante.
 */
declare(strict_types=1);

if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../../config/config.php';
}

$nombreUsuario = htmlspecialchars($_SESSION['usuario']['nombre'] ?? 'Usuario');
$rolUsuario    = $_SESSION['usuario']['rol'] ?? 'cliente';
$etiquetasRol  = [
    'admin'       => 'Administrador',
    'vendedor'    => 'Vendedor',
    'consultor'   => 'Consultor',
    'cliente'     => 'Cliente',
];
$etiquetaRol   = $etiquetasRol[$rolUsuario] ?? ucfirst($rolUsuario);
// En el apartado de admin (esquina superior derecha): mostrar solo "Administrador"
if ($rolUsuario === 'admin') {
    $nombreUsuario = 'Administrador';
    $etiquetaRol   = 'Administrador';
}
$iniciales     = strtoupper(mb_substr($nombreUsuario, 0, 1) . (strpos($nombreUsuario, ' ') !== false ? mb_substr($nombreUsuario, strpos($nombreUsuario, ' ') + 1, 1) : ''));
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ByteStock — Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #050810;
            --bg-card: rgba(12, 20, 40, 0.78);
            --blue-glow: #3b82f6;
            --blue-bright: #60a5fa;
            --blue-soft: #93c5fd;
            --border-glow: rgba(59, 130, 246, 0.35);
            --text-main: #e8f0fe;
            --text-muted: #94a3b8;
            --sidebar-w: 260px;
            --sidebar-collapsed: 72px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background:
                radial-gradient(ellipse 120% 80% at 10% -20%, rgba(59, 130, 246, 0.25) 0%, transparent 50%),
                radial-gradient(ellipse 100% 60% at 90% 10%, rgba(30, 64, 175, 0.2) 0%, transparent 45%),
                radial-gradient(ellipse 80% 50% at 50% 100%, rgba(15, 23, 42, 0.9) 0%, transparent 60%),
                linear-gradient(180deg, #0a1228 0%, #050810 40%, #020408 100%);
            color: var(--text-main);
            font-family: 'Inter', system-ui, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Efecto nublado / nieve flotante */
        .snow-layer {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 9999;
            overflow: hidden;
        }
        .snowflake {
            position: absolute;
            top: -12px;
            color: #c7d7fe;
            font-size: 11px;
            opacity: 0.65;
            animation: snowfall linear infinite;
            text-shadow: 0 0 8px rgba(147, 197, 253, 0.9);
            user-select: none;
        }
        @keyframes snowfall {
            0%   { transform: translateY(-10vh) translateX(0) rotate(0deg); opacity: 0; }
            10%  { opacity: 0.8; }
            90%  { opacity: 0.5; }
            100% { transform: translateY(110vh) translateX(50px) rotate(360deg); opacity: 0; }
        }

        /* Layout con sidebar */
        .app-layout {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: var(--sidebar-w);
            background: linear-gradient(180deg, rgba(8, 15, 35, 0.97) 0%, rgba(5, 10, 22, 0.98) 100%);
            border-right: 1px solid var(--border-glow);
            display: flex;
            flex-direction: column;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 100;
            transition: width 0.25s ease, transform 0.25s ease;
            box-shadow: 4px 0 30px rgba(0, 0, 0, 0.4);
        }
        .sidebar.collapsed {
            width: var(--sidebar-collapsed);
        }
        .sidebar.collapsed .brand-text,
        .sidebar.collapsed .menu-text,
        .sidebar.collapsed .badge-admin,
        .sidebar.collapsed .sidebar-footer .btn-cerrar-sesion {
            opacity: 0;
            width: 0;
            overflow: hidden;
            white-space: nowrap;
        }
        .sidebar.collapsed .menu-item {
            justify-content: center;
            padding-left: 0;
            padding-right: 0;
        }
        .sidebar.collapsed .menu-icon {
            margin-right: 0;
            font-size: 1.3rem;
        }

        .sidebar-brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 1.25rem 1.25rem 1rem;
            border-bottom: 1px solid rgba(59, 130, 246, 0.2);
        }
        .brand-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #3b82f6, #1e40af);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 0.95rem;
            color: #fff;
            box-shadow: 0 0 18px rgba(59, 130, 246, 0.5);
            flex-shrink: 0;
        }
        .brand-text {
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 1.05rem;
            letter-spacing: 0.5px;
            background: linear-gradient(90deg, #93c5fd, #60a5fa);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: opacity 0.2s;
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 1rem 0.75rem;
        }
        .menu-list {
            list-style: none;
        }
        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 1rem;
            margin-bottom: 4px;
            border-radius: 10px;
            color: var(--text-muted);
            text-decoration: none;
            transition: all 0.2s ease;
            position: relative;
        }
        .menu-item:hover {
            background: rgba(59, 130, 246, 0.12);
            color: var(--blue-soft);
        }
        .menu-item.active {
            background: linear-gradient(90deg, rgba(59, 130, 246, 0.25), rgba(59, 130, 246, 0.08));
            color: #fff;
            box-shadow: inset 3px 0 0 #3b82f6;
        }
        .menu-item.active .menu-icon {
            filter: drop-shadow(0 0 6px rgba(96, 165, 250, 0.8));
        }
        .menu-item.disabled {
            opacity: 0.45;
            pointer-events: none;
            cursor: not-allowed;
        }
        .menu-icon {
            font-size: 1.15rem;
            width: 28px;
            text-align: center;
            flex-shrink: 0;
            transition: margin 0.2s;
        }
        .menu-text {
            font-weight: 500;
            font-size: 0.95rem;
            transition: opacity 0.2s;
        }
        .badge-admin {
            font-size: 0.65rem;
            background: rgba(239, 68, 68, 0.2);
            color: #fca5a5;
            padding: 2px 6px;
            border-radius: 6px;
            margin-left: auto;
            white-space: nowrap;
        }

        .sidebar-footer {
            padding: 1rem;
            border-top: 1px solid rgba(59, 130, 246, 0.15);
        }
        .btn-cerrar-sesion {
            display: block;
            width: 100%;
            text-align: center;
            padding: 0.65rem;
            background: rgba(185, 28, 28, 0.25);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.35);
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.2s;
        }
        .btn-cerrar-sesion:hover {
            background: rgba(185, 28, 28, 0.45);
            color: #fff;
        }

        /* Botón colapso */
        .btn-toggle-sidebar {
            position: fixed;
            top: 1.1rem;
            left: calc(var(--sidebar-w) - 18px);
            z-index: 110;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 1px solid var(--border-glow);
            background: rgba(15, 30, 60, 0.95);
            color: var(--blue-soft);
            font-size: 1.1rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: left 0.25s ease, background 0.2s;
            box-shadow: 0 2px 12px rgba(0,0,0,0.4);
        }
        .btn-toggle-sidebar:hover {
            background: rgba(59, 130, 246, 0.3);
        }
        body.sidebar-collapsed .btn-toggle-sidebar {
            left: calc(var(--sidebar-collapsed) - 18px);
        }

        /* Contenido principal */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-w);
            min-height: 100vh;
            transition: margin-left 0.25s ease;
            display: flex;
            flex-direction: column;
        }
        body.sidebar-collapsed .main-content {
            margin-left: var(--sidebar-collapsed);
        }

        /* Top bar */
        .topbar {
            background: linear-gradient(90deg, rgba(10, 20, 45, 0.92), rgba(15, 35, 80, 0.85));
            backdrop-filter: blur(14px);
            border-bottom: 1px solid var(--border-glow);
            padding: 0.85rem 1.75rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 50;
        }
        .topbar-search {
            flex: 1;
            max-width: 360px;
            margin: 0 1.5rem;
        }
        .topbar-search input {
            width: 100%;
            background: rgba(15, 25, 50, 0.7);
            border: 1px solid rgba(59, 130, 246, 0.25);
            border-radius: 999px;
            padding: 0.5rem 1.1rem;
            color: var(--text-main);
            font-size: 0.9rem;
            outline: none;
            transition: border-color 0.2s;
        }
        .topbar-search input:focus {
            border-color: var(--blue-glow);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }
        .topbar-search input::placeholder {
            color: var(--text-muted);
        }
        .user-chip {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(59, 130, 246, 0.12);
            border: 1px solid rgba(59, 130, 246, 0.3);
            border-radius: 999px;
            padding: 0.35rem 0.85rem 0.35rem 0.4rem;
        }
        .user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 0.85rem;
            color: #fff;
            box-shadow: 0 0 12px rgba(59, 130, 246, 0.45);
        }
        .user-info {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }
        .user-name {
            font-weight: 600;
            font-size: 0.9rem;
        }
        .user-role {
            font-size: 0.72rem;
            color: var(--blue-soft);
        }

        /* Área de contenido */
        .content-area {
            padding: 1.75rem;
            flex: 1;
        }

        /* Tarjetas de indicadores */
        .card-kpi {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            border-radius: 16px;
            padding: 1.35rem 1.5rem;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.25);
            transition: transform 0.2s, box-shadow 0.2s;
            height: 100%;
        }
        .card-kpi:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 40px rgba(59, 130, 246, 0.18);
        }
        .kpi-label {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 0.4rem;
            font-weight: 500;
        }
        .kpi-value {
            font-size: 1.85rem;
            font-weight: 700;
            font-family: 'Orbitron', sans-serif;
            letter-spacing: -0.5px;
        }
        .kpi-value.green  { color: #34d399; }
        .kpi-value.blue   { color: #60a5fa; }
        .kpi-value.orange { color: #fb923c; }
        .kpi-value.red    { color: #f87171; }

        .section-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.35rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
            background: linear-gradient(90deg, #e0e7ff, #93c5fd);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .section-sub {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }

        /* Tabla usuarios recientes */
        .table-dark-custom {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-main);
            --bs-table-border-color: rgba(59, 130, 246, 0.15);
        }
        .table-dark-custom thead th {
            background: rgba(30, 58, 120, 0.4);
            color: var(--blue-soft);
            font-weight: 600;
            font-size: 0.85rem;
            border-bottom: 1px solid var(--border-glow);
        }
        .table-dark-custom tbody tr:hover {
            background: rgba(59, 130, 246, 0.08);
        }

        /* Responsive */
        @media (max-width: 991px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.show-mobile {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0 !important;
            }
            .btn-toggle-sidebar {
                left: 1rem !important;
            }
        }
    </style>
</head>
<body>
    <!-- Capa de nieve / efecto nublado -->
    <div class="snow-layer" id="snowLayer" aria-hidden="true"></div>

    <div class="app-layout">
        <?php require __DIR__ . '/menu.php'; ?>

        <div class="main-content">
            <header class="topbar">
                <div class="d-none d-md-block" style="width:40px"></div>
                <div class="topbar-search">
                    <input type="search" placeholder="Buscar…" aria-label="Buscar en el panel">
                </div>
                <div class="user-chip">
                    <div class="user-avatar" aria-hidden="true"><?= $iniciales ?></div>
                    <div class="user-info">
                        <span class="user-name"><?= $nombreUsuario ?></span>
                        <span class="user-role"><?= htmlspecialchars($etiquetaRol) ?></span>
                    </div>
                </div>
            </header>

            <main class="content-area">
