<?php
/**
 * Menú lateral construido desde configuración.
 * Solo muestra entradas permitidas por el rol del usuario.
 * Marca el elemento activo comparando el archivo/ruta actual.
 */
declare(strict_types=1);

if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../../config/config.php';
}

$rolActual = $_SESSION['usuario']['rol'] ?? 'cliente';
// Mapear 'admin' del sistema actual a 'administrador' del plan
if ($rolActual === 'admin') {
    $rolActual = 'administrador';
}

$archivoActual = basename($_SERVER['PHP_SELF'] ?? '');
$urlActual = $_GET['url'] ?? '';

$menuItems = [
    [
        'archivo' => 'dashboard',
        'texto'   => 'Tablero',
        'icono'   => '▦',
        'roles'   => ['administrador', 'vendedor', 'consultor', 'admin'],
    ],
    [
        'archivo' => 'admin_inventario',
        'texto'   => 'Productos',
        'icono'   => '📦',
        'roles'   => ['administrador', 'vendedor', 'consultor', 'admin'],
    ],
    [
        'archivo' => 'categorias',
        'texto'   => 'Categorías',
        'icono'   => '🏷',
        'roles'   => ['administrador', 'vendedor', 'admin'],
    ],
    [
        'archivo' => 'clientes',
        'texto'   => 'Clientes',
        'icono'   => '👥',
        'roles'   => ['administrador', 'vendedor', 'admin'],
    ],
    [
        'archivo' => 'pedidos',
        'texto'   => 'Pedidos',
        'icono'   => '🛒',
        'roles'   => ['administrador', 'vendedor', 'admin'],
    ],
    [
        'archivo' => 'reportes',
        'texto'   => 'Reportes',
        'icono'   => '📊',
        'roles'   => ['administrador', 'consultor', 'admin'],
    ],
    [
        'archivo' => 'usuarios',
        'texto'   => 'Usuarios',
        'icono'   => '👤',
        'roles'   => ['administrador', 'admin'],
        'solo_admin' => true,
    ],
    [
        'archivo' => 'solicitar_servicio',
        'texto'   => 'Catálogo',
        'icono'   => '💻',
        'roles'   => ['cliente'],
    ],
];

function menuEsActivo(string $archivo, string $urlActual, string $archivoActual): bool
{
    if ($urlActual === $archivo) {
        return true;
    }
    if ($archivoActual === $archivo . '.php') {
        return true;
    }
    if ($archivo === 'dashboard' && ($urlActual === '' || $urlActual === 'dashboard' || $urlActual === 'admin')) {
        return true;
    }
    return false;
}

if (!function_exists('menuUrl')) {
    function menuUrl(string $ruta): string
    {
        if (function_exists('url')) {
            return url($ruta);
        }
        return 'index.php?url=' . rawurlencode($ruta);
    }
}
?>
<aside class="sidebar" id="sidebar" aria-label="Menú principal">
    <div class="sidebar-brand">
        <span class="brand-icon">BS</span>
        <span class="brand-text">ByteStock</span>
    </div>
    <nav class="sidebar-nav" role="navigation">
        <ul class="menu-list">
            <?php foreach ($menuItems as $item): ?>
                <?php
                $rolSesion = $_SESSION['usuario']['rol'] ?? '';
                $permitido = in_array($rolActual, $item['roles'], true) || in_array($rolSesion, $item['roles'], true);
                if (!$permitido) {
                    continue;
                }
                $activo = menuEsActivo($item['archivo'], $urlActual, $archivoActual);
                $clase  = $activo ? 'menu-item active' : 'menu-item';
                $aria   = $activo ? ' aria-current="page"' : '';
                $href   = menuUrl($item['archivo']);
                $atenuado = !empty($item['solo_admin']) && $rolActual !== 'administrador' && $rolSesion !== 'admin';
                if ($atenuado) {
                    $clase .= ' disabled';
                }
                ?>
                <li>
                    <a href="<?= $atenuado ? '#' : htmlspecialchars($href) ?>"
                       class="<?= $clase ?>"
                       <?= $aria ?>
                       <?= $atenuado ? 'tabindex="-1" aria-disabled="true"' : '' ?>>
                        <span class="menu-icon"><?= $item['icono'] ?></span>
                        <span class="menu-text"><?= htmlspecialchars($item['texto']) ?></span>
                        <?php if (!empty($item['solo_admin'])): ?>
                            <span class="badge-admin">solo administrador</span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </nav>
    <div class="sidebar-footer">
        <a href="<?= htmlspecialchars(menuUrl('logout')) ?>" class="btn-cerrar-sesion" role="button">
            Cerrar sesión
        </a>
    </div>
</aside>
<button type="button"
        class="btn-toggle-sidebar"
        id="btnToggleSidebar"
        aria-controls="sidebar"
        aria-expanded="true"
        aria-label="Colapsar o expandir menú lateral">
    ☰
</button>
