<?php
/**
 * Pie para páginas públicas (login / registro).
 */
?>
    <script>
    (function () {
        const layer = document.getElementById('snowLayer');
        if (!layer) return;
        const chars = ['❄', '❅', '✦', '·', '∘'];
        for (let i = 0; i < 40; i++) {
            const flake = document.createElement('span');
            flake.className = 'snowflake';
            flake.textContent = chars[Math.floor(Math.random() * chars.length)];
            flake.style.left = Math.random() * 100 + '%';
            flake.style.fontSize = (8 + Math.random() * 10) + 'px';
            flake.style.animationDuration = (8 + Math.random() * 14) + 's';
            flake.style.animationDelay = (Math.random() * 8) + 's';
            layer.appendChild(flake);
        }
    })();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
