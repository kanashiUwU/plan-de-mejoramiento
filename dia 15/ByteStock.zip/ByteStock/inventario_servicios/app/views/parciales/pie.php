<?php
/**
 * Pie / cierre de página + scripts de accesibilidad del menú.
 */
?>
            </main>
        </div><!-- /.main-content -->
    </div><!-- /.app-layout -->

    <script>
    // Nieve flotante (efecto nublado)
    (function () {
        const layer = document.getElementById('snowLayer');
        if (!layer) return;
        const chars = ['❄', '❅', '✦', '·', '∘'];
        for (let i = 0; i < 40; i++) {
            const flake = document.createElement('span');
            flake.className = 'snowflake';
            flake.textContent = chars[Math.floor(Math.random() * chars.length)];
            flake.style.left = Math.random() * 100 + '%';
            flake.style.fontSize = (8 + Math.random() * 10) + 'px';
            flake.style.animationDuration = (8 + Math.random() * 14) + 's';
            flake.style.animationDelay = (Math.random() * 8) + 's';
            layer.appendChild(flake);
        }
    })();

    // Colapso del menú lateral + aria-expanded
    (function () {
        const btn = document.getElementById('btnToggleSidebar');
        const sidebar = document.getElementById('sidebar');
        if (!btn || !sidebar) return;

        btn.addEventListener('click', function () {
            const collapsed = sidebar.classList.toggle('collapsed');
            document.body.classList.toggle('sidebar-collapsed', collapsed);
            btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        });

        // Navegación por teclado: Escape cierra en móvil
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && sidebar.classList.contains('show-mobile')) {
                sidebar.classList.remove('show-mobile');
                btn.setAttribute('aria-expanded', 'false');
            }
        });
    })();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
