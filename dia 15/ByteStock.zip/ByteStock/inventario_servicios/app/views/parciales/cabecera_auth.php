<?php
/**
 * Cabecera para páginas públicas (login / registro).
 * Mismos estilos del tema; sin sidebar.
 */
declare(strict_types=1);
if (!defined('BASE_URL')) {
    require_once __DIR__ . '/../../config/config.php';
}
$tituloPagina = $tituloPagina ?? 'ByteStock';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($tituloPagina) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-deep: #050810;
            --bg-card: rgba(12, 20, 40, 0.78);
            --blue-glow: #3b82f6;
            --blue-bright: #60a5fa;
            --blue-soft: #93c5fd;
            --border-glow: rgba(59, 130, 246, 0.35);
            --text-main: #e8f0fe;
            --text-muted: #94a3b8;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            background:
                radial-gradient(ellipse 120% 80% at 10% -20%, rgba(59, 130, 246, 0.25) 0%, transparent 50%),
                radial-gradient(ellipse 100% 60% at 90% 10%, rgba(30, 64, 175, 0.2) 0%, transparent 45%),
                linear-gradient(180deg, #0a1228 0%, #050810 40%, #020408 100%);
            color: var(--text-main);
            font-family: 'Inter', system-ui, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }
        .snow-layer {
            position: fixed; inset: 0; pointer-events: none; z-index: 9999; overflow: hidden;
        }
        .snowflake {
            position: absolute; top: -12px; color: #c7d7fe; font-size: 11px; opacity: 0.65;
            animation: snowfall linear infinite;
            text-shadow: 0 0 8px rgba(147, 197, 253, 0.9);
            user-select: none;
        }
        @keyframes snowfall {
            0%   { transform: translateY(-10vh) translateX(0) rotate(0deg); opacity: 0; }
            10%  { opacity: 0.8; }
            90%  { opacity: 0.5; }
            100% { transform: translateY(110vh) translateX(50px) rotate(360deg); opacity: 0; }
        }
        .login-card {
            background: var(--bg-card);
            border: 1px solid var(--border-glow);
            border-radius: 20px;
            backdrop-filter: blur(18px);
            box-shadow: 0 20px 50px rgba(0,0,0,0.5), 0 0 40px rgba(59, 130, 246, 0.12);
        }
        .brand-title {
            font-family: 'Orbitron', sans-serif;
            background: linear-gradient(90deg, #e0e7ff, #93c5fd);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .form-control {
            background: rgba(8, 15, 35, 0.8);
            border: 1px solid var(--border-glow);
            color: var(--text-main);
        }
        .form-control:focus {
            background: rgba(8, 15, 35, 0.95);
            border-color: var(--blue-bright);
            color: var(--text-main);
            box-shadow: 0 0 0 0.2rem rgba(59, 130, 246, 0.25);
        }
        .form-label { color: var(--blue-soft); }
        a { color: var(--blue-bright); }
        a:hover { color: var(--blue-soft); }
    </style>
</head>
<body>
    <div class="snow-layer" id="snowLayer" aria-hidden="true"></div>
