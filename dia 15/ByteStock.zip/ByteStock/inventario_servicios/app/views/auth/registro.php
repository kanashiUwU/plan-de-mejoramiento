<?php
/**
 * Registro — usa parciales cabecera_auth / pie_auth (tema unificado).
 */
declare(strict_types=1);
$tituloPagina = 'ByteStock — Registro';
require __DIR__ . '/../parciales/cabecera_auth.php';
?>
<div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
    <div class="col-md-6 col-lg-5">
        <div class="login-card p-4 p-md-5">
            <div class="text-center mb-4">
                <h1 class="brand-title h3 mb-1">ByteStock</h1>
                <p class="text-muted mb-0">Crea tu cuenta</p>
            </div>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if (!empty($exito)): ?>
                <div class="alert alert-success"><?= htmlspecialchars($exito) ?></div>
            <?php endif; ?>
            <form method="POST" action="<?= htmlspecialchars(function_exists('url') ? url('registro') : 'index.php?url=registro') ?>">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">Nombre completo</label>
                    <input type="text" name="nombre" class="form-control" required placeholder="Tu nombre" value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Correo</label>
                    <input type="email" name="correo" class="form-control" required placeholder="tu@email.com" value="<?= htmlspecialchars($_POST['correo'] ?? '') ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Teléfono</label>
                    <input type="text" name="telefono" class="form-control" required placeholder="3001234567" value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
                </div>
                <div class="mb-4">
                    <label class="form-label">Contraseña</label>
                    <input type="password" name="password" class="form-control" required placeholder="Mínimo 8 caracteres" minlength="8">
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2 mb-3">Registrarme</button>
            </form>
            <p class="text-center text-muted mb-0" style="font-size:0.9rem;">
                ¿Ya tienes cuenta?
                <a href="<?= htmlspecialchars(function_exists('url') ? url('login') : 'index.php?url=login') ?>">Inicia sesión</a>
            </p>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../parciales/pie_auth.php'; ?>
