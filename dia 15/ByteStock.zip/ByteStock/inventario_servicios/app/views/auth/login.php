<?php
/**
 * Login — usa parciales cabecera_auth / pie_auth (tema unificado).
 */
declare(strict_types=1);
$tituloPagina = 'ByteStock — Iniciar sesión';
require __DIR__ . '/../parciales/cabecera_auth.php';
?>
<div class="container min-vh-100 d-flex align-items-center justify-content-center py-5">
    <div class="col-md-5 col-lg-4">
        <div class="login-card p-4 p-md-5">
            <div class="text-center mb-4">
                <h1 class="brand-title h3 mb-1">ByteStock</h1>
                <p class="text-muted mb-0">Inicia sesión en tu cuenta</p>
            </div>
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <?php if (!empty($_GET['m'])): ?>
                <div class="alert alert-warning">
                    <?php
                    $msgs = [
                        'sesion_requerida' => 'Debes iniciar sesión para continuar.',
                        'sesion_invalida'  => 'Sesión inválida. Vuelve a entrar.',
                        'sesion_expirada'  => 'Tu sesión expiró por inactividad.',
                    ];
                    echo htmlspecialchars($msgs[$_GET['m']] ?? 'Mensaje del sistema');
                    ?>
                </div>
            <?php endif; ?>
            <form method="POST" action="<?= htmlspecialchars(function_exists('url') ? url('login') : 'index.php?url=login') ?>">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label">Correo</label>
                    <input type="email" name="correo" class="form-control" required placeholder="tu@email.com" autocomplete="username">
                </div>
                <div class="mb-4">
                    <label class="form-label">Contraseña</label>
                    <input type="password" name="password" class="form-control" required placeholder="••••••••" autocomplete="current-password">
                </div>
                <button type="submit" class="btn btn-primary w-100 py-2 mb-3">Entrar</button>
            </form>
            <p class="text-center text-muted mb-0" style="font-size:0.9rem;">
                ¿No tienes cuenta?
                <a href="<?= htmlspecialchars(function_exists('url') ? url('registro') : 'index.php?url=registro') ?>">Regístrate</a>
            </p>
        </div>
    </div>
</div>
<?php require __DIR__ . '/../parciales/pie_auth.php'; ?>
