<?php
/**
 * Catálogo / vista cliente — permite hacer pedidos de productos.
 * Los pedidos aparecen en el panel del administrador (Pedidos).
 */
declare(strict_types=1);
require __DIR__ . '/../parciales/cabecera.php';
?>

<div class="text-center mb-4">
    <h1 class="section-title mb-2">💻 Bienvenidos a ByteStock</h1>
    <p class="section-sub mb-0">Tu tienda de tecnología · Consulta productos y haz tus pedidos</p>
</div>

<?php if (!empty($flash)): ?>
    <div class="alert alert-<?= $flash['tipo'] === 'ok' ? 'success' : 'danger' ?> border-0 mb-3"
         style="background: <?= $flash['tipo'] === 'ok' ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)' ?>; color: <?= $flash['tipo'] === 'ok' ? '#86efac' : '#fca5a5' ?>; border-radius: 12px;">
        <?= htmlspecialchars($flash['msg']) ?>
    </div>
<?php endif; ?>
<?php if (!empty($error)): ?>
    <div class="alert border-0 mb-3" style="background: rgba(239,68,68,0.15); color: #fca5a5; border-radius: 12px;">
        <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<div class="row justify-content-center mb-4">
    <div class="col-md-8">
        <form method="GET" action="<?= htmlspecialchars(function_exists('url') ? url() : 'index.php') ?>" class="d-flex gap-2">
            <input type="hidden" name="url" value="solicitar_servicio">
            <input type="search" name="q" class="form-control form-control-lg"
                   placeholder="Buscar producto... (ej: mouse, laptop, switch)"
                   value="<?= htmlspecialchars($busqueda ?? '') ?>"
                   style="border-radius: 12px;">
            <button type="submit" class="btn btn-primary px-4" style="border-radius: 12px; white-space: nowrap;">🔍 Buscar</button>
            <?php if (!empty($busqueda)): ?>
                <a href="<?= htmlspecialchars(function_exists('url') ? url('solicitar_servicio') : 'index.php?url=solicitar_servicio') ?>" class="btn btn-outline-light px-3" style="border-radius: 12px;">Limpiar</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<div class="text-center mb-3">
    <h3 class="section-title" style="font-size: 1.25rem;">
        Catálogo de productos
        <?php if (!empty($busqueda)): ?>
            <span class="text-muted fw-normal" style="font-size: 0.95rem;">· resultados para “<?= htmlspecialchars($busqueda) ?>”</span>
        <?php endif; ?>
    </h3>
</div>

<?php if (empty($productos)): ?>
    <div class="alert text-center border-0" style="background: rgba(30,50,90,0.4); color: #94a3b8; border-radius: 14px;">
        No se encontraron productos<?= !empty($busqueda) ? ' con ese criterio' : '' ?>.
    </div>
<?php else: ?>
<div class="row g-3 mb-4">
    <?php foreach ($productos as $prod): ?>
    <?php
        $stock = (int)($prod['cantidad'] ?? 0);
        $puedePedir = $stock > 0;
    ?>
    <div class="col-md-4 col-lg-3">
        <div class="card-kpi h-100" style="border-top: 3px solid #3b82f6;">
            <div class="d-flex flex-column h-100">
                <?php if (!empty($prod['imagen'])): ?>
                    <div class="mb-3 text-center" style="height: 140px; overflow: hidden; border-radius: 10px; background: rgba(0,0,0,0.3);">
                        <img src="<?= htmlspecialchars($prod['imagen']) ?>"
                             alt="<?= htmlspecialchars($prod['nombre_producto']) ?>"
                             style="max-height: 140px; max-width: 100%; object-fit: contain;"
                             onerror="this.style.display='none'">
                    </div>
                <?php else: ?>
                    <div class="text-center mb-2"><span style="font-size: 2.2rem;">🖥️</span></div>
                <?php endif; ?>
                <div class="d-flex align-items-center justify-content-between mb-1">
                    <span class="badge <?= $stock > 0 ? 'bg-primary' : 'bg-danger' ?>">
                        Stock: <?= $stock ?>
                    </span>
                </div>
                <h4 class="mt-1 mb-2" style="color: #93c5fd; font-weight: 600; font-size: 1.05rem;">
                    <?= htmlspecialchars($prod['nombre_producto']) ?>
                </h4>
                <p class="text-muted flex-grow-1" style="font-size: 0.85rem; line-height: 1.4;">
                    <?= htmlspecialchars($prod['descripcion'] ?: 'Sin descripción') ?>
                </p>
                <div class="mt-2 pt-2" style="border-top: 1px solid rgba(59,130,246,0.2);">
                    <h3 class="fw-bold mb-2" style="font-size: 1.35rem; color: #60a5fa;">
                        $<?= number_format((float)($prod['precio'] ?? 0), 0) ?>
                        <span class="fs-6 text-muted fw-normal">COP</span>
                    </h3>
                    <?php if ($puedePedir): ?>
                        <form method="POST" action="<?= htmlspecialchars(function_exists('url') ? url('solicitar_servicio') : 'index.php?url=solicitar_servicio') ?>" class="mt-1">
                            <?= csrf_field() ?>
                            <input type="hidden" name="hacer_pedido" value="1">
                            <input type="hidden" name="producto_id" value="<?= (int)$prod['id'] ?>">
                            <div class="d-flex gap-2 align-items-center mb-2">
                                <label class="text-muted mb-0" style="font-size:0.8rem; white-space:nowrap;">Cant:</label>
                                <input type="number" name="cantidad" min="1" max="<?= $stock ?>" value="1"
                                       class="form-control form-control-sm" style="width:70px; border-radius:8px;" required>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm w-100" style="border-radius: 10px;">
                                🛒 Hacer pedido
                            </button>
                        </form>
                    <?php else: ?>
                        <span class="badge rounded-pill" style="background: rgba(239,68,68,0.2); color: #fca5a5; border: 1px solid rgba(239,68,68,0.35); font-size: 0.75rem;">
                            Sin stock
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="row mb-3">
    <div class="col-12 text-center">
        <p class="text-muted" style="font-size: 0.9rem;">
            Los pedidos que realices aparecerán en el panel del <strong>Administrador</strong> (sección Pedidos) con estado <em>pendiente</em>.
        </p>
    </div>
</div>

<?php require __DIR__ . '/../parciales/pie.php'; ?>
